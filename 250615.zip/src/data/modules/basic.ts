import { SpaceInfo } from '@/store/editorStore';
import { calculateSpaceIndexing } from '@/editor/shared/utils/indexing';

// ModuleData 인터페이스 정의 (modules.ts에서 복사)
export interface ModuleData {
  id: string;
  name: string;
  category: 'full';
  dimensions: {
    width: number;
    height: number;
    depth: number;
  };
  color: string;
  description?: string;
  hasDoor?: boolean;
  isDynamic?: boolean;
  widthOptions?: number[];
  type?: 'basic' | 'box' | 'shelf';
  modelConfig?: {
    wallThickness?: number;
    hasOpenFront?: boolean;
    hasShelf?: boolean;
    shelfCount?: number;
  };
}

/**
 * 기본 오픈 박스 모듈들
 * 
 * 앞면이 열린 기본적인 수납 공간을 제공하는 모듈들입니다.
 * 선반이나 칸막이 없는 단순한 박스 형태입니다.
 */
export const generateBasicModules = (
  internalSpace: { width: number; height: number; depth: number }, 
  spaceInfo?: SpaceInfo
): ModuleData[] => {
  const { height: maxHeight, depth: internalDepth } = internalSpace;
  
  // 가구 최대 깊이 = 내경 깊이 - 백패널 두께(20mm)
  const maxFurnitureDepth = Math.max(internalDepth - 20, 130); // 최소 130mm 보장
  
  // SpaceInfo가 제공되면 그대로 사용, 아니면 필요한 속성만 갖는 객체 생성
  let indexingSpaceInfo: SpaceInfo;
  
  if (spaceInfo) {
    indexingSpaceInfo = spaceInfo;
  } else {
    indexingSpaceInfo = {
      width: 3600,
      height: 2400,
      depth: 580,
      installType: 'built-in',
      wallConfig: { left: true, right: true },
      hasFloorFinish: false,
      surroundType: 'surround'
    };
  }
  
  // 컬럼 계산 로직 가져오기
  const indexing = calculateSpaceIndexing(indexingSpaceInfo);
  const columnWidth = indexing.columnWidth;
  const columnCount = indexing.columnCount;
  
  const modules: ModuleData[] = [];
  
  // 싱글 오픈 박스 모듈
  modules.push({
    id: `box-open-${columnWidth}`,
    name: `오픈 박스 ${columnWidth}mm`,
    category: 'full',
    dimensions: { 
      width: columnWidth, 
      height: maxHeight, 
      depth: maxFurnitureDepth
    },
    color: '#3E2723',
    description: `앞면 오픈형 박스 | 판재 20mm | 폭 ${columnWidth}mm × 높이 ${maxHeight}mm × 깊이 ${maxFurnitureDepth}mm`,
    isDynamic: true,
    hasDoor: true,
    widthOptions: [columnWidth, columnWidth * 2],
    type: 'box',
    modelConfig: {
      wallThickness: 20,
      hasOpenFront: true
    }
  });
  
  // 컬럼이 2개 이상인 경우 듀얼 컬럼 모듈 추가
  if (columnCount >= 2) {
    const dualColumnWidth = columnWidth * 2;
    
    // 듀얼 오픈 박스 모듈
    modules.push({
      id: `box-dual-${dualColumnWidth}`,
      name: `듀얼 오픈 박스 ${dualColumnWidth}mm`,
      category: 'full',
      dimensions: { 
        width: dualColumnWidth, 
        height: maxHeight, 
        depth: maxFurnitureDepth
      },
      color: '#3E2723',
      description: `2컬럼 오픈 박스 | 판재 20mm | 폭 ${dualColumnWidth}mm × 높이 ${maxHeight}mm × 깊이 ${maxFurnitureDepth}mm`,
      isDynamic: true,
      hasDoor: true,
      widthOptions: [columnWidth, dualColumnWidth],
      type: 'box',
      modelConfig: {
        wallThickness: 20,
        hasOpenFront: true
      }
    });
  }
  
  return modules;
};

