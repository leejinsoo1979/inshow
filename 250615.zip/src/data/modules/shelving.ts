import { SpaceInfo } from '@/store/editorStore';
import { calculateSpaceIndexing } from '@/editor/shared/utils/indexing';
import { ModuleData } from './basic';

/**
 * 선반형 모듈들
 * 
 * 내부에 선반이 구성된 수납 모듈들입니다.
 * 2단, 7단 등 다양한 선반 구성을 제공합니다.
 */
export const generateShelvingModules = (
  internalSpace: { width: number; height: number; depth: number }, 
  spaceInfo?: SpaceInfo
): ModuleData[] => {
  const { height: maxHeight, depth: internalDepth } = internalSpace;
  
  // 가구 최대 깊이 = 내경 깊이 - 백패널 두께(20mm)
  const maxFurnitureDepth = Math.max(internalDepth - 20, 130); // 최소 130mm 보장
  
  // SpaceInfo가 제공되면 그대로 사용, 아니면 필요한 속성만 갖는 객체 생성
  let indexingSpaceInfo: SpaceInfo;
  
  if (spaceInfo) {
    indexingSpaceInfo = spaceInfo;
  } else {
    indexingSpaceInfo = {
      width: 3600,
      height: 2400,
      depth: 580,
      installType: 'built-in',
      wallConfig: { left: true, right: true },
      hasFloorFinish: false,
      surroundType: 'surround'
    };
  }
  
  // 컬럼 계산 로직 가져오기
  const indexing = calculateSpaceIndexing(indexingSpaceInfo);
  const columnWidth = indexing.columnWidth;
  const columnCount = indexing.columnCount;
  
  const modules: ModuleData[] = [];
  
  // 싱글 2단 수납장 (중간 선반 추가)
  modules.push({
    id: `box-shelf-single-${columnWidth}`,
    name: `싱글 2단 ${columnWidth}mm`,
    category: 'full',
    dimensions: { 
      width: columnWidth, 
      height: maxHeight, 
      depth: maxFurnitureDepth
    },
    color: '#4E342E',
    description: `2단 수납장 | 중간선반 20mm | 폭 ${columnWidth}mm × 높이 ${maxHeight}mm × 깊이 ${maxFurnitureDepth}mm`,
    isDynamic: true,
    hasDoor: true,
    widthOptions: [columnWidth],
    type: 'box',
    modelConfig: {
      wallThickness: 20,
      hasOpenFront: true,
      hasShelf: true,
      shelfCount: 1
    }
  });
  
  // 싱글 7단 수납장 (6개의 중간 선반 추가)
  modules.push({
    id: `box-shelf-7tier-${columnWidth}`,
    name: `싱글 7단 ${columnWidth}mm`,
    category: 'full',
    dimensions: { 
      width: columnWidth, 
      height: maxHeight, 
      depth: maxFurnitureDepth
    },
    color: '#5D4037',
    description: `7단 수납장 | 6개 중간선반 20mm | 폭 ${columnWidth}mm × 높이 ${maxHeight}mm × 깊이 ${maxFurnitureDepth}mm`,
    isDynamic: true,
    hasDoor: true,
    widthOptions: [columnWidth],
    type: 'box',
    modelConfig: {
      wallThickness: 20,
      hasOpenFront: true,
      hasShelf: true,
      shelfCount: 6  // 7단이므로 6개의 중간 선반 필요
    }
  });
  
  // 컬럼이 2개 이상인 경우 듀얼 컬럼 모듈 추가
  if (columnCount >= 2) {
    const dualColumnWidth = columnWidth * 2;
    
    // 듀얼 2단 수납장 (양쪽 칸에 중간 선반 추가)
    modules.push({
      id: `box-shelf-dual-${dualColumnWidth}`,
      name: `듀얼 2단 ${dualColumnWidth}mm`,
      category: 'full',
      dimensions: { 
        width: dualColumnWidth, 
        height: maxHeight, 
        depth: maxFurnitureDepth
      },
      color: '#4E342E',
      description: `2컬럼 2단 수납장 | 양쪽 중간선반 20mm | 폭 ${dualColumnWidth}mm × 높이 ${maxHeight}mm × 깊이 ${maxFurnitureDepth}mm`,
      isDynamic: true,
      hasDoor: true,
      widthOptions: [dualColumnWidth],
      type: 'box',
      modelConfig: {
        wallThickness: 20,
        hasOpenFront: true,
        hasShelf: true,
        shelfCount: 2 // 듀얼은 양쪽에 선반이므로 2개
      }
    });
    
    // 듀얼 7단 수납장 (양쪽 칸에 각각 6개의 중간 선반 추가)
    modules.push({
      id: `box-shelf-7tier-dual-${dualColumnWidth}`,
      name: `듀얼 7단 ${dualColumnWidth}mm`,
      category: 'full',
      dimensions: { 
        width: dualColumnWidth, 
        height: maxHeight, 
        depth: maxFurnitureDepth
      },
      color: '#5D4037',
      description: `2컬럼 7단 수납장 | 양쪽 6개 중간선반 20mm | 폭 ${dualColumnWidth}mm × 높이 ${maxHeight}mm × 깊이 ${maxFurnitureDepth}mm`,
      isDynamic: true,
      hasDoor: true,
      widthOptions: [dualColumnWidth],
      type: 'box',
      modelConfig: {
        wallThickness: 20,
        hasOpenFront: true,
        hasShelf: true,
        shelfCount: 12 // 듀얼 7단이므로 양쪽에 각각 6개씩 총 12개
      }
    });
  }
  
  return modules;
}; 