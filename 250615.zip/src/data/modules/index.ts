import { SpaceInfo } from '@/store/editorStore';
import { generateBasicModules } from './basic';
import { generateShelvingModules } from './shelving';

// ModuleData를 별도로 import
import type { ModuleData } from './basic';

// 공통 타입들 re-export
export type { ModuleData };

/**
 * 모든 동적 모듈들을 생성하는 통합 함수
 */
export const generateDynamicModules = (
  internalSpace: { width: number; height: number; depth: number }, 
  spaceInfo?: SpaceInfo
): ModuleData[] => {
  const basicModules = generateBasicModules(internalSpace, spaceInfo);
  const shelvingModules = generateShelvingModules(internalSpace, spaceInfo);
  
  return [
    ...basicModules,
    ...shelvingModules
  ];
};

/**
 * 정적 모듈들 (기본 모듈, 참고용)
 */
export const STATIC_MODULES: ModuleData[] = [];

export const getModulesByCategory = (
  category: ModuleData['category'], 
  internalSpace: { width: number; height: number; depth: number },
  spaceInfo?: SpaceInfo
) => {
  const dynamicModules = generateDynamicModules(internalSpace, spaceInfo);
  const staticModules = STATIC_MODULES;
  
  return [...dynamicModules, ...staticModules].filter(module => module.category === category);
};

export const getModuleById = (
  id: string, 
  internalSpace?: { width: number; height: number; depth: number },
  spaceInfo?: SpaceInfo
) => {
  if (internalSpace) {
    const dynamicModules = generateDynamicModules(internalSpace, spaceInfo);
    const found = dynamicModules.find(module => module.id === id);
    if (found) return found;
  }
  
  return STATIC_MODULES.find(module => module.id === id);
};

/**
 * 모듈이 내경 공간에 맞는지 검증
 */
export const validateModuleForInternalSpace = (
  module: ModuleData, 
  internalSpace: { width: number; height: number; depth: number }
) => {
  const { width, height, depth } = module.dimensions;
  
  return {
    fitsWidth: width <= internalSpace.width,
    fitsHeight: height <= internalSpace.height,
    fitsDepth: depth <= internalSpace.depth,
    isValid: width <= internalSpace.width && 
             height <= internalSpace.height && 
             depth <= internalSpace.depth
  };
};

/**
 * 내경 공간에 맞는 모듈들만 필터링
 */
export const getValidModulesForInternalSpace = (
  internalSpace: { width: number; height: number; depth: number }
) => {
  const dynamicModules = generateDynamicModules(internalSpace);
  const staticModules = STATIC_MODULES;
  
  return [...dynamicModules, ...staticModules].filter(module => 
    validateModuleForInternalSpace(module, internalSpace).isValid
  );
}; 