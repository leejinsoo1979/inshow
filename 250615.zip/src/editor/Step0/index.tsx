import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './style.module.css';
import Button from '@/components/common/Button';
import { useEditorStore } from '@/store/editorStore';
import { 
  BasicInfoControls, 
  WidthControl,
  HeightControl,
  DepthControl,
  InstallTypeControls 
} from '@/editor/shared/controls';
import { useFurnitureData } from '@/editor/shared/furniture/providers/FurnitureDataProvider';

// 개발 환경 체크
const isDevelopment = import.meta.env.DEV;

const Step0: React.FC = () => {
  const navigate = useNavigate();
  const { 
    basicInfo, 
    setBasicInfo, 
    spaceInfo,
    setSpaceInfo
  } = useEditorStore();

  const { clearAllModules } = useFurnitureData();

  // Step0 컴포넌트 마운트 시 가구 데이터 초기화
  useEffect(() => {
    clearAllModules();
  }, []); // 빈 의존성 배열로 변경하여 마운트 시에만 실행



  const handleBasicInfoUpdate = (updates: Partial<typeof basicInfo>) => {
    setBasicInfo(updates);
  };

  const handleSpaceInfoUpdate = (updates: Partial<typeof spaceInfo>) => {
    setSpaceInfo(updates);
  };

  const handleNext = () => {
    if (basicInfo.title && basicInfo.location) {
      navigate('/configurator');
    }
  };

  const canProceed = basicInfo.title && basicInfo.location;

  return (
    <div 
      className={styles.container}
      data-debug={isDevelopment ? "step0" : undefined}
      data-component="Step0"
    >
      <div 
        className={styles.modalContent}
        data-debug-element="modalContent"
      >
        <div 
          className={styles.header}
          data-debug-element="header"
        >
          
          <div>
            <h1>벽장 제작</h1>
            <p>기본 정보와 공간 크기를 설정해주세요.</p>
          </div>
        </div>

        <div 
          className={styles.content}
          data-debug-element="content"  
        >
          <div 
            className={styles.formSection}
            data-debug-element="formSection"
          >
            

            <div 
              className={styles.form}
              data-debug-element="form"
            >
              <BasicInfoControls 
                basicInfo={basicInfo} 
                onUpdate={handleBasicInfoUpdate}
              />
              
              <div 
                className={styles.spaceSettings}
                data-debug-element="spaceSettings"
              >
                <h3 className={styles.sectionTitle}>공간 정보</h3>
                
                <div className={styles.spaceSizeSection}>
                  <span className={styles.label}>공간 크기</span>
                  
                  {/* 전체 크기 요약 표시 */}
                  <div className={styles.dimensionsSummary}>
                    <span className={styles.summaryText}>
                      {spaceInfo.width} × {spaceInfo.height} × {spaceInfo.depth} mm
                    </span>
                  </div>
                  
                  <div className={styles.inputGroupThreeColumns}>
                    <WidthControl 
                      spaceInfo={spaceInfo}
                      onUpdate={handleSpaceInfoUpdate}
                    />
                    <HeightControl 
                      spaceInfo={spaceInfo}
                      onUpdate={handleSpaceInfoUpdate}
                    />
                    <DepthControl 
                      spaceInfo={spaceInfo}
                      onUpdate={handleSpaceInfoUpdate}
                    />
                  </div>
                </div>
                
                <InstallTypeControls 
                  spaceInfo={spaceInfo}
                  onUpdate={handleSpaceInfoUpdate}
                />
              </div>
            </div>

            <div 
              className={styles.startButtonContainer}
              data-debug-element="startButtonContainer"
            >
              <Button
                variant="primary"
                size="large"
                onClick={handleNext}
                disabled={!canProceed}
                data-debug-element="startButton"
              >
                벽장 제작 시작하기
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Step0;
