import React, { useState, useEffect } from 'react';
import { useEditorStore } from '@/store/editorStore';
import { useUIStore } from '@/store/uiStore';
import styles from './style.module.css';
import { 
  WidthControl,
  HeightControl,
  InstallTypeControls, 
  FloorFinishControls, 
  SurroundControls,
  BaseControls
} from '@/editor/shared/controls';
import Space3DView from '@/editor/shared/viewer3d/Space3DView';
import { withFurnitureSpaceAdapter, WithFurnitureSpaceAdapterProps } from '@/editor/shared/furniture/providers/withFurnitureSpaceAdapter';
import ModuleLibrary from '@/editor/shared/controls/furniture/ModuleLibrary';
import ModulePropertiesPanel from '@/editor/shared/controls/furniture/ModulePropertiesPanel';
import PlacedModulePropertiesPanel from '@/editor/shared/controls/furniture/PlacedModulePropertiesPanel';
import MaterialPanel from '@/editor/shared/controls/styling/MaterialPanel';
import ExportPanel from './components/controls/ExportPanel';


type LeftPanelTab = 'module' | 'material';

// 가구 보존 로직을 사용하는 내부 컴포넌트
const ConfiguratorContent: React.FC<WithFurnitureSpaceAdapterProps> = ({
  updateFurnitureForNewSpace
}) => {
    const {
    spaceInfo,
    setSpaceInfo
  } = useEditorStore();
  
  const { viewMode, setViewMode } = useUIStore();
  
  // 좌측 패널 탭 상태
  const [leftPanelTab, setLeftPanelTab] = useState<LeftPanelTab>('module');

  // 공간 변경 로직 처리
  const [previousSpaceInfo, setPreviousSpaceInfo] = useState(spaceInfo);

  useEffect(() => {
    // spaceInfo가 변경되었을 때만 실행
    if (JSON.stringify(previousSpaceInfo) !== JSON.stringify(spaceInfo)) {
      // materialConfig만 변경된 경우는 가구 재배치를 하지 않음
      const prevWithoutMaterial = { ...previousSpaceInfo };
      const currentWithoutMaterial = { ...spaceInfo };
      delete prevWithoutMaterial.materialConfig;
      delete currentWithoutMaterial.materialConfig;
      
      // materialConfig를 제외한 나머지 속성이 변경된 경우에만 가구 업데이트
      if (JSON.stringify(prevWithoutMaterial) !== JSON.stringify(currentWithoutMaterial)) {
        console.log('🔄 Space dimensions changed, updating furniture positions');
        updateFurnitureForNewSpace(previousSpaceInfo, spaceInfo);
      } else {
        console.log('🎨 Only material config changed, keeping furniture positions');
      }
      
      // 이전 상태 업데이트
      setPreviousSpaceInfo(spaceInfo);
    }
  }, [spaceInfo, previousSpaceInfo, updateFurnitureForNewSpace]);

  const handleSpaceInfoUpdate = (updates: Partial<typeof spaceInfo>) => {
    setSpaceInfo(updates);
  };





  // 좌측 패널 컨텐츠 렌더링
  const renderLeftPanelContent = () => {
    switch (leftPanelTab) {
      case 'module':
        return (
          <div className={styles.leftPanelContent}>
            <h3 className={styles.modulePanelTitle}>가구 모듈</h3>
            <div className={styles.moduleSection}>
              <ModuleLibrary />
            </div>
          </div>
        );
      case 'material':
        return <MaterialPanel />;
      default:
        return null;
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.editorWithTabs}>
        {/* 제일 좌측: 아이콘 탭 메뉴 */}
        <div className={styles.leftTabMenu}>
          <button
            className={`${styles.tabIcon} ${leftPanelTab === 'module' ? styles.activeTabIcon : ''}`}
            onClick={() => setLeftPanelTab('module')}
            title="모듈"
          >
            <span>📦</span>
            <span className={styles.tabIconLabel}>모듈</span>
          </button>
          <button
            className={`${styles.tabIcon} ${leftPanelTab === 'material' ? styles.activeTabIcon : ''}`}
            onClick={() => setLeftPanelTab('material')}
            title="재질"
          >
            <span>🎨</span>
            <span className={styles.tabIconLabel}>재질</span>
          </button>
        </div>

        {/* 좌측: 선택된 탭에 따른 컨텐츠 패널 */}
        <div className={styles.leftContentPanel}>
          {renderLeftPanelContent()}
        </div>

        {/* 가운데: 3D 뷰어 */}
        <div className={styles.centerViewer}>
          {/* 2D/3D 전환 버튼 */}
          <div className={styles.viewModeToggle}>
            <button
              className={`${styles.viewModeButton} ${viewMode === '2D' ? styles.active : ''}`}
              onClick={() => setViewMode('2D')}
            >
              2D
            </button>
            <button
              className={`${styles.viewModeButton} ${viewMode === '3D' ? styles.active : ''}`}
              onClick={() => setViewMode('3D')}
            >
              3D
            </button>

          </div>
          
          <Space3DView 
            spaceInfo={spaceInfo}
            viewMode={viewMode}
            svgSize={{ width: 600, height: 400 }}
          />
        </div>

        {/* 우측: 공간 설정 패널 */}
        <div className={styles.customControlsPanel}>
          <div className={styles.spaceSettingsHeader}>
            <h3 className={styles.spaceSettingsTitle}>공간 설정</h3>
          </div>

          <div className={styles.content}>
            <div className={styles.spaceControls}>
              <div className={styles.spaceSizeSection}>
                <span className={styles.sectionLabel}>공간 크기</span>
                
                {/* 전체 크기 요약 표시 */}
                <div className={styles.dimensionsSummary}>
                  <span className={styles.summaryText}>
                    {spaceInfo.width} × {spaceInfo.height} × {spaceInfo.depth} mm
                  </span>
                </div>
                
                <div className={styles.inputGroupTwoColumns}>
                  <WidthControl 
                    spaceInfo={spaceInfo}
                    onUpdate={handleSpaceInfoUpdate}
                  />
                  <HeightControl 
                    spaceInfo={spaceInfo}
                    onUpdate={handleSpaceInfoUpdate}
                  />
                </div>
              </div>
              <InstallTypeControls 
                spaceInfo={spaceInfo}
                onUpdate={handleSpaceInfoUpdate}
              />
              <FloorFinishControls 
                spaceInfo={spaceInfo}
                onUpdate={handleSpaceInfoUpdate}
              />
              <SurroundControls 
                spaceInfo={spaceInfo}
                onUpdate={handleSpaceInfoUpdate}
              />
              <BaseControls 
                spaceInfo={spaceInfo}
                onUpdate={handleSpaceInfoUpdate}
              />
            </div>
            
            {/* 도면 내보내기 패널 */}
            <ExportPanel />
          </div>
          
          {/* 속성 패널 오버레이 - 공간설정 패널만 오버레이 */}
          <ModulePropertiesPanel />
          {/* 배치된 가구 편집 속성창 */}
          <PlacedModulePropertiesPanel />
        </div>
      </div>
    </div>
  );
};

// HOC로 공간 변경 기능을 추가한 ConfiguratorContent
const ConfiguratorContentWithSpaceAdapter = withFurnitureSpaceAdapter(ConfiguratorContent);

const Configurator: React.FC = () => {
  return (
    <ConfiguratorContentWithSpaceAdapter />
  );
};

export default Configurator; 