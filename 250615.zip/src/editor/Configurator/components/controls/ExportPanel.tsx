import React, { useState } from 'react';
import { useEditorStore } from '@/store/editorStore';
import { useFurnitureData } from '@/editor/shared/furniture/providers';
import { useDXFExport } from '@/editor/shared/hooks/useDXFExport';
import styles from './ExportPanel.module.css';

/**
 * 도면 내보내기 패널 컴포넌트
 * 오른쪽 컨트롤 패널 하단에 위치
 */
const ExportPanel: React.FC = () => {
  const { spaceInfo } = useEditorStore();
  const { placedModules } = useFurnitureData();
  const { exportToDXF, canExportDXF, getExportStatusMessage } = useDXFExport();
  
  const [isExporting, setIsExporting] = useState(false);
  const [lastExportResult, setLastExportResult] = useState<{
    success: boolean;
    message: string;
    filename?: string;
  } | null>(null);

  // DXF 내보내기 실행
  const handleExportDXF = async () => {
    if (!spaceInfo || !canExportDXF(spaceInfo, placedModules)) {
      return;
    }

    setIsExporting(true);
    setLastExportResult(null);

    try {
      const result = await exportToDXF(spaceInfo, placedModules);
      setLastExportResult(result);
      
      // 성공 메시지는 3초 후 자동 사라짐
      if (result.success) {
        setTimeout(() => {
          setLastExportResult(null);
        }, 3000);
      }
    } catch {
      setLastExportResult({
        success: false,
        message: '예상치 못한 오류가 발생했습니다.'
      });
    } finally {
      setIsExporting(false);
    }
  };

  const isExportEnabled = spaceInfo && canExportDXF(spaceInfo, placedModules);
  const statusMessage = spaceInfo ? getExportStatusMessage(spaceInfo, placedModules) : '공간 정보가 없습니다.';

  return (
    <div className={styles.exportPanel}>
      <div className={styles.header}>
        <h3 className={styles.title}>📐 정면도 출력</h3>
        <p className={styles.description}>
          현재 가구 배치를 정면도 CAD 도면(DXF)으로 내보냅니다
        </p>
      </div>

      <div className={styles.status}>
        <div className={styles.statusMessage}>
          {statusMessage}
        </div>
        
        {spaceInfo && (
          <div className={styles.spaceInfo}>
            <span className={styles.spaceSize}>
              {spaceInfo.width}W × {spaceInfo.height}H × {spaceInfo.depth}D mm
            </span>
            <span className={styles.moduleCount}>
              {placedModules.length}개 가구
            </span>
          </div>
        )}
      </div>

      <div className={styles.actions}>
        <button
          className={`${styles.exportButton} ${!isExportEnabled ? styles.disabled : ''}`}
          onClick={handleExportDXF}
          disabled={!isExportEnabled || isExporting}
        >
          {isExporting ? (
            <>
              <span className={styles.spinner}></span>
              내보내는 중...
            </>
          ) : (
            <>
              <span className={styles.icon}>📄</span>
              DXF 정면도 다운로드
            </>
          )}
        </button>
      </div>

      {lastExportResult && (
        <div className={`${styles.result} ${lastExportResult.success ? styles.success : styles.error}`}>
          <div className={styles.resultMessage}>
            {lastExportResult.success ? '✅' : '❌'} {lastExportResult.message}
          </div>
          {lastExportResult.filename && (
            <div className={styles.filename}>
              파일명: {lastExportResult.filename}
            </div>
          )}
        </div>
      )}

      <div className={styles.info}>
        <div className={styles.infoItem}>
          <span className={styles.infoLabel}>파일 형식:</span>
          <span className={styles.infoValue}>DXF (AutoCAD 호환)</span>
        </div>
        <div className={styles.infoItem}>
          <span className={styles.infoLabel}>축척:</span>
          <span className={styles.infoValue}>1:100</span>
        </div>
        <div className={styles.infoItem}>
          <span className={styles.infoLabel}>단위:</span>
          <span className={styles.infoValue}>밀리미터(mm)</span>
        </div>
      </div>
    </div>
  );
};

export default ExportPanel; 