import React, { useState } from 'react';
import { PlacedModule, CurrentDragData } from './types';
import { FurnitureContext, FurnitureContextType } from './FurnitureContext';
import { useFurnitureSpaceAdapter } from './hooks';

export const FurnitureProvider = ({ children }: { children: React.ReactNode }) => {
  // 배치된 모듈 상태 관리
  const [placedModules, setPlacedModules] = useState<PlacedModule[]>([]);
  // 선택된 라이브러리 모듈 ID
  const [selectedLibraryModuleId, setSelectedLibraryModuleId] = useState<string | null>(null);
  // 선택된 배치된 모듈 ID
  const [selectedPlacedModuleId, setSelectedPlacedModuleId] = useState<string | null>(null);
  // 가구 배치 모드 상태 관리
  const [isFurniturePlacementMode, setIsFurniturePlacementMode] = useState<boolean>(false);
  // 전역 드래그 상태 관리
  const [currentDragData, setCurrentDragData] = useState<CurrentDragData | null>(null);
  // 편집모드 상태 관리
  const [editMode, setEditMode] = useState<boolean>(false);
  const [editingModuleId, setEditingModuleId] = useState<string | null>(null);

  // 공간 변경 관련 로직을 커스텀 훅으로 분리
  const {
    spaceChangeMode,
    setSpaceChangeMode,
    preserveFurnitureOnSpaceChange,
    updateFurnitureForNewSpace
  } = useFurnitureSpaceAdapter({ setPlacedModules });

  // 가구 배치 모드 설정 함수
  const setFurniturePlacementMode = (mode: boolean) => {
    setIsFurniturePlacementMode(mode);
  };

  // 편집모드 종료 헬퍼 함수
  const exitEditMode = () => {
    setEditMode(false);
    setEditingModuleId(null);
  };



  // 모듈 추가 함수
  const addModule = (module: PlacedModule) => {
    setPlacedModules(prev => [...prev, module]);
    setSelectedLibraryModuleId(null); // 배치 후 선택 초기화
    setSelectedPlacedModuleId(null); // 배치 후 선택 초기화
    // 새 가구 배치시 기존 편집모드 종료
    exitEditMode();
  };

  // 모듈 제거 함수
  const removeModule = (id: string) => {
    setPlacedModules(prev => prev.filter(module => module.id !== id));
  };

  // 모듈 이동 함수
  const moveModule = (id: string, position: { x: number; y: number; z: number }) => {
    setPlacedModules(prev => 
      prev.map(module => 
        module.id === id 
          ? { ...module, position } 
          : module
      )
    );
  };

  // 배치된 모듈 속성 업데이트 함수
  const updatePlacedModule = (id: string, updates: Partial<PlacedModule>) => {
    setPlacedModules(prev => 
      prev.map(module => 
        module.id === id 
          ? { ...module, ...updates } 
          : module
      )
    );
  };

  // 모든 가구 초기화 함수
  const clearAllModules = () => {
    setPlacedModules([]);
    setSelectedLibraryModuleId(null);
    setSelectedPlacedModuleId(null);
    exitEditMode();
  };



  // 컨텍스트 값
  const value: FurnitureContextType = {
    placedModules,
    selectedLibraryModuleId,
    selectedPlacedModuleId,
    setSelectedLibraryModuleId,
    setSelectedPlacedModuleId,
    addModule,
    removeModule,
    moveModule,
    updatePlacedModule,
    clearAllModules,
    updateFurnitureForNewSpace,
    isFurniturePlacementMode,
    setFurniturePlacementMode,
    currentDragData,
    setCurrentDragData,
    editMode,
    editingModuleId,
    setEditMode,
    setEditingModuleId,
    exitEditMode,
    spaceChangeMode,
    setSpaceChangeMode,
    preserveFurnitureOnSpaceChange
  };

  return (
    <FurnitureContext.Provider value={value}>
      {children}
    </FurnitureContext.Provider>
  );
};

export default FurnitureProvider; 