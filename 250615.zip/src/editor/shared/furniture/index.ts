// 타입들
export * from './types';

// 새로운 분리된 Provider들
export * from './providers';

// 커스텀 훅들
export * from './hooks';

// 레거시 호환성을 위한 기존 Provider와 훅 (deprecated)
export type { FurnitureContextType } from './FurnitureContext';
export { FurnitureProvider } from './FurnitureProvider';
export { FurnitureContext } from './FurnitureContext';
export { useFurniture } from './useFurniture'; 