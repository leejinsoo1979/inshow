import { useState, useCallback } from 'react';
import { PlacedModule } from '../types';
import { SpaceInfo } from '@/store/editorStore';
import { filterAndAdjustFurniture, calculateSpaceIndexing, findSlotIndexFromPosition } from '@/editor/shared/utils/indexing';
import { calculateInternalSpace } from '@/editor/shared/viewer3d/utils/geometry';
import { getModuleById } from '@/data/modules';

interface UseFurnitureSpaceAdapterProps {
  setPlacedModules: React.Dispatch<React.SetStateAction<PlacedModule[]>>;
}

export const useFurnitureSpaceAdapter = ({ setPlacedModules }: UseFurnitureSpaceAdapterProps) => {
  // 공간 변경 모드 상태 관리
  const [spaceChangeMode, setSpaceChangeMode] = useState<boolean>(false);

  // 공간 변경 시 가구 보존 메서드
  const preserveFurnitureOnSpaceChange = useCallback((oldSpaceInfo: SpaceInfo, newSpaceInfo: SpaceInfo): Promise<{
    preservedCount: number;
    removedCount: number;
    removedFurnitureIds: string[];
  }> => {
    return new Promise((resolve) => {
      // 현재 placedModules 상태를 함수형 업데이트로 가져와서 처리
      setPlacedModules(currentModules => {
        // 가구가 없으면 바로 리턴
        if (currentModules.length === 0) {
          resolve({
            preservedCount: 0,
            removedCount: 0,
            removedFurnitureIds: []
          });
          return currentModules;
        }
        
        // 공간 변경 모드 활성화
        setSpaceChangeMode(true);
        
        // 기존 가구들에 슬롯 정보 추가
        const indexing = calculateSpaceIndexing(oldSpaceInfo);
        const internalSpace = calculateInternalSpace(oldSpaceInfo);
        
        const furnitureWithSlotInfo = currentModules.map(module => {
          // 이미 슬롯 정보가 있으면 패스
          if (module.slotIndex !== undefined && module.isDualSlot !== undefined) {
            return module;
          }
          
          // 모듈 데이터 가져오기
          const moduleData = getModuleById(module.moduleId, internalSpace, oldSpaceInfo);
          if (!moduleData) {
            console.warn(`⚠️ Module data not found for ${module.moduleId}`);
            return module;
          }
          
          // 듀얼 가구 여부 판별
          const isDualFurniture = Math.abs(moduleData.dimensions.width - (indexing.columnWidth * 2)) < 50;
          
          // 위치로부터 슬롯 인덱스 계산
          const slotIndex = findSlotIndexFromPosition(module.position, indexing, isDualFurniture);
          
          if (slotIndex >= 0) {
            return {
              ...module,
              slotIndex,
              isDualSlot: isDualFurniture,
              isValidInCurrentSpace: true
            };
          }
          
          return module;
        });
        
        // getModuleById 래퍼 함수 (타입 호환성을 위해)
        const getModuleByIdWrapper = (moduleId: string, internalSpace: { width: number; height: number; depth: number }, spaceInfo: SpaceInfo) => {
          const result = getModuleById(moduleId, internalSpace, spaceInfo);
          return result || null; // undefined를 null로 변환
        };
        
        try {
          // 슬롯 정보가 업데이트된 가구 목록을 사용하여 필터링 및 위치 조정
          const result = filterAndAdjustFurniture(
            furnitureWithSlotInfo,
            oldSpaceInfo,
            newSpaceInfo,
            getModuleByIdWrapper
          );
          
          // 공간 변경 모드 비활성화 (약간의 지연 후)
          setTimeout(() => {
            setSpaceChangeMode(false);
          }, 1000);
          
          // 완료 알림
          resolve({
            preservedCount: result.validFurniture.length,
            removedCount: result.removedFurniture.length,
            removedFurnitureIds: result.removedFurniture
          });
          
          // 유효한 가구들 반환
          return result.validFurniture;
        } catch (error) {
          console.error('❌ Error during furniture preservation:', error);
          
          // 공간 변경 모드 비활성화
          setTimeout(() => {
            setSpaceChangeMode(false);
          }, 1000);
          
          resolve({
            preservedCount: 0,
            removedCount: currentModules.length,
            removedFurnitureIds: currentModules.map(m => m.id)
          });
          
          return currentModules; // 에러 시 원래 상태 유지
        }
      });
    });
  }, [setPlacedModules]);

  // 새로운 공간에 맞게 가구 업데이트 함수 (간단한 버전)
  const updateFurnitureForNewSpace = useCallback((oldSpaceInfo: SpaceInfo, newSpaceInfo: SpaceInfo) => {
    setPlacedModules(currentModules => {
      if (currentModules.length === 0) return currentModules;
      
      const oldIndexing = calculateSpaceIndexing(oldSpaceInfo);
      const newIndexing = calculateSpaceIndexing(newSpaceInfo);
      
      console.log(`🔄 Updating furniture for space change:`);
      console.log(`  Old space: ${oldSpaceInfo.width}mm → New space: ${newSpaceInfo.width}mm`);
      console.log(`  Old columns: ${oldIndexing.columnCount} (${oldIndexing.columnWidth}mm each)`);
      console.log(`  New columns: ${newIndexing.columnCount} (${newIndexing.columnWidth}mm each)`);
      console.log(`  Old internal width: ${oldIndexing.internalWidth}mm → New internal width: ${newIndexing.internalWidth}mm`);
      
      const updatedModules: PlacedModule[] = [];
      
      currentModules.forEach(module => {
        // 슬롯 인덱스 계산 (이미 있으면 사용, 없으면 위치로부터 계산)
        let slotIndex = module.slotIndex;
        if (slotIndex === undefined) {
          const oldInternalSpace = calculateInternalSpace(oldSpaceInfo);
          const moduleData = getModuleById(module.moduleId, oldInternalSpace, oldSpaceInfo);
          if (moduleData) {
            const isDualFurniture = Math.abs(moduleData.dimensions.width - (oldIndexing.columnWidth * 2)) < 50;
            slotIndex = findSlotIndexFromPosition(module.position, oldIndexing, isDualFurniture);
          }
        }
        
        if (slotIndex === undefined || slotIndex < 0) {
          console.log(`❌ Removing furniture ${module.id} - invalid slot`);
          return; // 제거할 가구
        }
        
        // 새로운 moduleId 계산 (동적 모듈의 경우 숫자 부분을 새로운 컬럼 폭으로 교체)
        let newModuleId = module.moduleId;
        let isDualModule = false;
        
        // 듀얼 모듈 패턴 처리 (숫자가 컬럼폭*2인 경우)
        const dualPatterns = [
          /^box-dual-(\d+)$/,
          /^box-shelf-dual-(\d+)$/,
          /^box-shelf-7tier-dual-(\d+)$/
        ];
        
        for (const pattern of dualPatterns) {
          const match = module.moduleId.match(pattern);
          if (match) {
            const oldWidth = parseInt(match[1]);
            // 듀얼 모듈인지 확인 (기존 폭이 컬럼폭*2와 유사한지)
            if (Math.abs(oldWidth - (oldIndexing.columnWidth * 2)) < 50) {
              newModuleId = module.moduleId.replace(pattern, (full, oldNum) => 
                full.replace(oldNum, (newIndexing.columnWidth * 2).toString())
              );
              isDualModule = true;
              break;
            }
          }
        }
        
        // 싱글 모듈 패턴 처리 (듀얼이 아닌 경우)
        if (!isDualModule) {
          const singlePatterns = [
            /^box-open-(\d+)$/,
            /^box-shelf-single-(\d+)$/,
            /^box-shelf-7tier-(\d+)$/
          ];
          
          for (const pattern of singlePatterns) {
            const match = module.moduleId.match(pattern);
            if (match) {
              newModuleId = module.moduleId.replace(pattern, (full, oldNum) => 
                full.replace(oldNum, newIndexing.columnWidth.toString())
              );
              break;
            }
          }
        }
        
        // 새 공간에서 슬롯이 유효한지 확인
        if (slotIndex >= newIndexing.columnCount) {
          console.log(`❌ Removing furniture ${module.id} - slot ${slotIndex} not available (only ${newIndexing.columnCount} columns)`);
          return; // 제거할 가구
        }
        
        // 듀얼 가구의 경우 추가 검증: 다음 슬롯도 유효해야 함
        if (isDualModule && (slotIndex + 1) >= newIndexing.columnCount) {
          console.log(`❌ Removing dual furniture ${module.id} - requires slots ${slotIndex} and ${slotIndex + 1}, but only ${newIndexing.columnCount} columns available`);
          return; // 제거할 가구
        }
        
        // 새로운 위치 계산
        let newX: number;
        if (isDualModule && newIndexing.threeUnitDualPositions) {
          // 듀얼 가구: 듀얼 위치 배열 사용
          newX = newIndexing.threeUnitDualPositions[slotIndex];
        } else {
          // 싱글 가구: 일반 위치 배열 사용
          newX = newIndexing.threeUnitPositions[slotIndex];
        }
        const oldX = module.position.x;
        
        console.log(`✅ Updated furniture ${module.id}:`);
        console.log(`  Module: ${module.moduleId} → ${newModuleId}`);
        console.log(`  Slot: ${slotIndex} | Position: ${oldX.toFixed(3)} → ${newX.toFixed(3)}`);
        console.log(`  Column width: ${oldIndexing.columnWidth}mm → ${newIndexing.columnWidth}mm`);
        
        updatedModules.push({
          ...module,
          moduleId: newModuleId,
          position: { ...module.position, x: newX },
          slotIndex,
          isDualSlot: newModuleId.includes('dual'),
          isValidInCurrentSpace: true
        });
      });
      
      return updatedModules;
    });
  }, [setPlacedModules]);

  return {
    spaceChangeMode,
    setSpaceChangeMode,
    preserveFurnitureOnSpaceChange,
    updateFurnitureForNewSpace
  };
}; 