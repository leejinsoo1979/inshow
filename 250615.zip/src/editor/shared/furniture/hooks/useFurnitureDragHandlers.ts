import React from 'react';
import { SpaceInfo } from '@/store/editorStore';
import { calculateSpaceIndexing } from '@/editor/shared/utils/indexing';
import { useFurnitureData, useFurnitureUI } from '@/editor/shared/furniture/providers';
import { useSlotOccupancy } from './useSlotOccupancy';
import { useDropPositioning } from './useDropPositioning';

export const useFurnitureDragHandlers = (spaceInfo: SpaceInfo) => {
  const { addModule, placedModules } = useFurnitureData();
  const { setFurniturePlacementMode } = useFurnitureUI();
  const { checkSlotOccupancy } = useSlotOccupancy(spaceInfo);
  const { calculateDropPosition, findAvailableSlot } = useDropPositioning(spaceInfo);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDragLeave = () => {
    // 드래그 리브 처리
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    
    try {
      const dragDataString = e.dataTransfer.getData('application/json');
      if (!dragDataString) return;
      
      const currentDragData = JSON.parse(dragDataString);
      
      if (currentDragData && currentDragData.type === 'furniture') {
        // 드롭 위치 계산
        const dropPosition = calculateDropPosition(e, currentDragData);
        if (!dropPosition) return;

        const indexing = calculateSpaceIndexing(spaceInfo);
        let finalX = dropPosition.x;
        
        // 중복 배치 확인 - 슬롯 기반 충돌 검사 사용
        const isBlocked = checkSlotOccupancy(dropPosition.column, dropPosition.isDualFurniture, indexing, placedModules);
        
        // 충돌이 감지되면 다음 사용 가능한 슬롯 찾기
        if (isBlocked) {
          const availableSlot = findAvailableSlot(
            dropPosition.column,
            dropPosition.isDualFurniture,
            indexing,
            checkSlotOccupancy,
            placedModules
          );
          
          if (!availableSlot) {
            return;
          }
          
          finalX = availableSlot.x;
        }
        
        // 고유 ID 생성
        const placedId = `placed-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        // 새 모듈 배치
        const newModule = {
          id: placedId,
          moduleId: currentDragData.moduleData.id,
          position: {
            x: finalX,
            y: 0,
            z: 0
          },
          rotation: 0,
          hasDoor: currentDragData.moduleData.hasDoor ?? true // 도어 정보 포함
        };
        
        addModule(newModule);
      }
    } catch (error) {
      console.error('Error handling drop:', error);
    }
    
    setFurniturePlacementMode(false);
  };

  return {
    handleDragOver,
    handleDragLeave,
    handleDrop
  };
}; 