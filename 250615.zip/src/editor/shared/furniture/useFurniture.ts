import { useContext } from 'react';
import { FurnitureContext, FurnitureContextType } from './FurnitureContext';

// 기본값 정의
const defaultContext: FurnitureContextType = {
  placedModules: [],
  selectedLibraryModuleId: null,
  selectedPlacedModuleId: null,
  setSelectedLibraryModuleId: () => {},
  setSelectedPlacedModuleId: () => {},
  addModule: () => {},
  removeModule: () => {},
  moveModule: () => {},
  updatePlacedModule: () => {},
  clearAllModules: () => {},
  updateFurnitureForNewSpace: () => {},
  isFurniturePlacementMode: false,
  setFurniturePlacementMode: () => {},
  currentDragData: null,
  setCurrentDragData: () => {},
  editMode: false,
  editingModuleId: null,
  setEditMode: () => {},
  setEditingModuleId: () => {},
  exitEditMode: () => {},
  spaceChangeMode: false,
  setSpaceChangeMode: () => {},
  preserveFurnitureOnSpaceChange: () => Promise.resolve({
    preservedCount: 0,
    removedCount: 0,
    removedFurnitureIds: []
  })
};

// 가구 관리 hook
export const useFurniture = (): FurnitureContextType => {
  const context = useContext(FurnitureContext);
  
  if (!context) {
    console.warn('useFurniture is used outside of FurnitureProvider. Some functionality may not work.');
    return defaultContext;
  }
  
  return context;
}; 