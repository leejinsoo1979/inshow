import React from 'react';
import { 
  FurnitureDataProvider,
  FurnitureSelectionProvider, 
  FurnitureUIProvider,
  FurnitureDragProvider
} from './index';

// 모든 가구 관련 Provider를 조합하는 통합 Provider
export const FurnitureProviders: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <FurnitureDataProvider>
      <FurnitureSelectionProvider>
        <FurnitureUIProvider>
          <FurnitureDragProvider>
            {children}
          </FurnitureDragProvider>
        </FurnitureUIProvider>
      </FurnitureSelectionProvider>
    </FurnitureDataProvider>
  );
}; 