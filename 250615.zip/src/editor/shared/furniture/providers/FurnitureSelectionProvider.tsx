import React, { useState, createContext, useContext } from 'react';

// 가구 선택 상태 관리 컨텍스트 타입 정의
interface FurnitureSelectionContextType {
  selectedLibraryModuleId: string | null;
  selectedPlacedModuleId: string | null;
  setSelectedLibraryModuleId: (id: string | null) => void;
  setSelectedPlacedModuleId: (id: string | null) => void;
  clearAllSelections: () => void;
}

// 컨텍스트 생성
const FurnitureSelectionContext = createContext<FurnitureSelectionContextType | null>(null);

// Provider 컴포넌트
export const FurnitureSelectionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 선택된 라이브러리 모듈 ID
  const [selectedLibraryModuleId, setSelectedLibraryModuleId] = useState<string | null>(null);
  // 선택된 배치된 모듈 ID
  const [selectedPlacedModuleId, setSelectedPlacedModuleId] = useState<string | null>(null);

  // 모든 선택 상태 초기화 함수
  const clearAllSelections = () => {
    setSelectedLibraryModuleId(null);
    setSelectedPlacedModuleId(null);
  };

  // 컨텍스트 값
  const value: FurnitureSelectionContextType = {
    selectedLibraryModuleId,
    selectedPlacedModuleId,
    setSelectedLibraryModuleId,
    setSelectedPlacedModuleId,
    clearAllSelections
  };

  return (
    <FurnitureSelectionContext.Provider value={value}>
      {children}
    </FurnitureSelectionContext.Provider>
  );
};

// 커스텀 훅
export const useFurnitureSelection = (): FurnitureSelectionContextType => {
  const context = useContext(FurnitureSelectionContext);
  
  if (!context) {
    throw new Error('useFurnitureSelection은 FurnitureSelectionProvider 내부에서 사용되어야 합니다.');
  }
  
  return context;
}; 