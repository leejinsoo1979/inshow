import React, { useState, createContext, useContext } from 'react';
import { PlacedModule } from '../types';

// 가구 데이터 관리 컨텍스트 타입 정의
interface FurnitureDataContextType {
  placedModules: PlacedModule[];
  addModule: (module: PlacedModule) => void;
  removeModule: (id: string) => void;
  updatePlacedModule: (id: string, updates: Partial<PlacedModule>) => void;
  clearAllModules: () => void;
  moveModule: (id: string, position: { x: number; y: number; z: number }) => void;
}

// 컨텍스트 생성
const FurnitureDataContext = createContext<FurnitureDataContextType | null>(null);

// Provider 컴포넌트
export const FurnitureDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 배치된 모듈 상태 관리
  const [placedModules, setPlacedModules] = useState<PlacedModule[]>([]);

  // 모듈 추가 함수 (순수하게 데이터만 관리)
  const addModule = (module: PlacedModule) => {
    setPlacedModules(prev => [...prev, module]);
  };

  // 모듈 제거 함수
  const removeModule = (id: string) => {
    setPlacedModules(prev => prev.filter(module => module.id !== id));
  };

  // 모듈 이동 함수
  const moveModule = (id: string, position: { x: number; y: number; z: number }) => {
    setPlacedModules(prev => 
      prev.map(module => 
        module.id === id 
          ? { ...module, position } 
          : module
      )
    );
  };

  // 배치된 모듈 속성 업데이트 함수
  const updatePlacedModule = (id: string, updates: Partial<PlacedModule>) => {
    setPlacedModules(prev => 
      prev.map(module => 
        module.id === id 
          ? { ...module, ...updates } 
          : module
      )
    );
  };

  // 모든 가구 초기화 함수
  const clearAllModules = () => {
    setPlacedModules([]);
  };

  // 컨텍스트 값
  const value: FurnitureDataContextType = {
    placedModules,
    addModule,
    removeModule,
    moveModule,
    updatePlacedModule,
    clearAllModules
  };

  return (
    <FurnitureDataContext.Provider value={value}>
      {children}
    </FurnitureDataContext.Provider>
  );
};

// 커스텀 훅
export const useFurnitureData = (): FurnitureDataContextType => {
  const context = useContext(FurnitureDataContext);
  
  if (!context) {
    throw new Error('useFurnitureData는 FurnitureDataProvider 내부에서 사용되어야 합니다.');
  }
  
  return context;
}; 