import React, { useState, createContext, useContext } from 'react';
import { CurrentDragData } from '../types';

// 가구 드래그 상태 관리 컨텍스트 타입 정의
interface FurnitureDragContextType {
  currentDragData: CurrentDragData | null;
  setCurrentDragData: (data: CurrentDragData | null) => void;
  clearDragData: () => void;
}

// 컨텍스트 생성
const FurnitureDragContext = createContext<FurnitureDragContextType | null>(null);

// Provider 컴포넌트
export const FurnitureDragProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 전역 드래그 상태 관리
  const [currentDragData, setCurrentDragData] = useState<CurrentDragData | null>(null);

  // 드래그 데이터 초기화 함수
  const clearDragData = () => {
    setCurrentDragData(null);
  };

  // 컨텍스트 값
  const value: FurnitureDragContextType = {
    currentDragData,
    setCurrentDragData,
    clearDragData
  };

  return (
    <FurnitureDragContext.Provider value={value}>
      {children}
    </FurnitureDragContext.Provider>
  );
};

// 커스텀 훅
export const useFurnitureDrag = (): FurnitureDragContextType => {
  const context = useContext(FurnitureDragContext);
  
  if (!context) {
    throw new Error('useFurnitureDrag는 FurnitureDragProvider 내부에서 사용되어야 합니다.');
  }
  
  return context;
}; 