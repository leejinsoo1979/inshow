import React, { useState, createContext, useContext } from 'react';

// 가구 UI 상태 관리 컨텍스트 타입 정의
interface FurnitureUIContextType {
  isFurniturePlacementMode: boolean;
  editMode: boolean;
  editingModuleId: string | null;
  setFurniturePlacementMode: (mode: boolean) => void;
  setEditMode: (mode: boolean) => void;
  setEditingModuleId: (id: string | null) => void;
  exitEditMode: () => void;
}

// 컨텍스트 생성
const FurnitureUIContext = createContext<FurnitureUIContextType | null>(null);

// Provider 컴포넌트
export const FurnitureUIProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 가구 배치 모드 상태 관리
  const [isFurniturePlacementMode, setIsFurniturePlacementMode] = useState<boolean>(false);
  // 편집모드 상태 관리
  const [editMode, setEditMode] = useState<boolean>(false);
  const [editingModuleId, setEditingModuleId] = useState<string | null>(null);

  // 편집모드 종료 헬퍼 함수
  const exitEditMode = () => {
    setEditMode(false);
    setEditingModuleId(null);
  };

  // 컨텍스트 값
  const value: FurnitureUIContextType = {
    isFurniturePlacementMode,
    editMode,
    editingModuleId,
    setFurniturePlacementMode: setIsFurniturePlacementMode,
    setEditMode,
    setEditingModuleId,
    exitEditMode
  };

  return (
    <FurnitureUIContext.Provider value={value}>
      {children}
    </FurnitureUIContext.Provider>
  );
};

// 커스텀 훅
export const useFurnitureUI = (): FurnitureUIContextType => {
  const context = useContext(FurnitureUIContext);
  
  if (!context) {
    throw new Error('useFurnitureUI는 FurnitureUIProvider 내부에서 사용되어야 합니다.');
  }
  
  return context;
}; 