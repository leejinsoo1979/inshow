import React from 'react';
import { SpaceInfo } from '@/store/editorStore';
import { useFurnitureSpaceAdapter } from '../hooks';
import { useFurnitureData } from './FurnitureDataProvider';

// 공간 변경 관련 기능을 제공하는 HOC
export interface WithFurnitureSpaceAdapterProps {
  spaceChangeMode: boolean;
  setSpaceChangeMode: (mode: boolean) => void;
  preserveFurnitureOnSpaceChange: (oldSpaceInfo: SpaceInfo, newSpaceInfo: SpaceInfo) => Promise<{
    preservedCount: number;
    removedCount: number;
    removedFurnitureIds: string[];
  }>;
  updateFurnitureForNewSpace: (oldSpaceInfo: SpaceInfo, newSpaceInfo: SpaceInfo) => void;
}

// HOC 함수
export function withFurnitureSpaceAdapter<P extends object>(
  WrappedComponent: React.ComponentType<P & WithFurnitureSpaceAdapterProps>
): React.FC<P> {
  return function WithFurnitureSpaceAdapterComponent(props: P) {
    // FurnitureDataProvider 내부에서 사용되어야 함
    const furnitureData = useFurnitureData();
    
    // 공간 변경 어댑터 훅 사용
    const spaceAdapterProps = useFurnitureSpaceAdapter({
      setPlacedModules: (updater) => {
        // 함수형 업데이트 지원
        if (typeof updater === 'function') {
          const currentModules = furnitureData.placedModules;
          const newModules = updater(currentModules);
          // 개별 모듈 업데이트로 변환
          furnitureData.clearAllModules();
          newModules.forEach(module => furnitureData.addModule(module));
        }
      }
    });

    return (
      <WrappedComponent 
        {...props} 
        {...spaceAdapterProps}
      />
    );
  };
} 