import { createContext } from 'react';
import { PlacedModule, CurrentDragData } from './types';
import { SpaceInfo } from '@/store/editorStore';

// 가구 관리 컨텍스트를 위한 타입 정의
export interface FurnitureContextType {
  placedModules: PlacedModule[];
  
  // 선택 상태를 용도별로 분리
  selectedLibraryModuleId: string | null; // 가구 라이브러리에서 선택된 모듈
  selectedPlacedModuleId: string | null;  // 배치된 가구에서 선택된 모듈
  setSelectedLibraryModuleId: (id: string | null) => void;
  setSelectedPlacedModuleId: (id: string | null) => void;
  
  addModule: (module: PlacedModule) => void;
  removeModule: (id: string) => void;
  moveModule: (id: string, position: { x: number; y: number; z: number }) => void;
  updatePlacedModule: (id: string, updates: Partial<PlacedModule>) => void; // 배치된 모듈 속성 업데이트
  clearAllModules: () => void; // 모든 가구 초기화 함수 추가
  updateFurnitureForNewSpace: (oldSpaceInfo: SpaceInfo, newSpaceInfo: SpaceInfo) => void; // 새 공간에 맞게 가구 업데이트
  
  // 가구 배치 모드 상태
  isFurniturePlacementMode: boolean;
  setFurniturePlacementMode: (mode: boolean) => void;
  
  // 전역 드래그 상태 (R3F 메시에서 접근용)
  currentDragData: CurrentDragData | null;
  setCurrentDragData: (data: CurrentDragData | null) => void;
  
  // 편집모드 상태 (전역 관리)
  editMode: boolean;
  editingModuleId: string | null;
  setEditMode: (mode: boolean) => void;
  setEditingModuleId: (id: string | null) => void;
  exitEditMode: () => void; // 편집모드 종료 헬퍼 함수
  
  // 공간 변경 시 가구 보존 관련 기능
  spaceChangeMode: boolean; // 공간 변경 중인지 표시
  setSpaceChangeMode: (mode: boolean) => void;
  preserveFurnitureOnSpaceChange: (oldSpaceInfo: SpaceInfo, newSpaceInfo: SpaceInfo) => Promise<{
    preservedCount: number;
    removedCount: number;
    removedFurnitureIds: string[];
  }>;
}

// 가구 관리 컨텍스트 생성
export const FurnitureContext = createContext<FurnitureContextType | null>(null); 