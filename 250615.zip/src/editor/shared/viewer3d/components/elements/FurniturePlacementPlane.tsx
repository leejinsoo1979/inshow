import React from 'react';
import { Plane, Edges } from '@react-three/drei';
import { SpaceInfo } from '@/store/editorStore';
import { calculateInternalSpace, calculateFrameThickness } from '../../utils/geometry';
import { useFurnitureUI } from '@/editor/shared/furniture/providers';

interface FurniturePlacementPlaneProps {
  spaceInfo: SpaceInfo;
}

const FurniturePlacementPlane: React.FC<FurniturePlacementPlaneProps> = ({ spaceInfo }) => {
  const { isFurniturePlacementMode } = useFurnitureUI();
  
  // 내경 공간 계산
  const internalSpace = calculateInternalSpace(spaceInfo);
  
  // 프레임 두께 계산
  const frameThickness = calculateFrameThickness(spaceInfo);
  
  // mm를 Three.js 단위로 변환
  const mmToThreeUnits = (mm: number) => mm * 0.01;
  
  // 전체 공간과 내경 공간의 중심 차이 계산
  const totalWidth = spaceInfo.width;
  const internalCenterX = -(totalWidth / 2) + frameThickness.left + (internalSpace.width / 2);
  const internalCenterXThreeUnits = mmToThreeUnits(internalCenterX);
  
  // 바닥재 높이 계산
  const floorFinishHeightMm = spaceInfo.hasFloorFinish && spaceInfo.floorFinish ? spaceInfo.floorFinish.height : 0;
  const baseFrameHeightMm = spaceInfo.baseConfig?.height || 0;
  
  // 받침대 설정에 따른 기준면 높이 계산
  let planeY: number;
  
  if (!spaceInfo.baseConfig || spaceInfo.baseConfig.type === 'floor') {
    // 받침대 있음: 바닥재 + 받침대 높이
    planeY = mmToThreeUnits(floorFinishHeightMm + baseFrameHeightMm);
  } else if (spaceInfo.baseConfig.type === 'stand') {
    // 받침대 없음
    if (spaceInfo.baseConfig.placementType === 'float') {
      // 띄워서 배치: 바닥재 + 띄움 높이
      const floatHeightMm = spaceInfo.baseConfig.floatHeight || 0;
      planeY = mmToThreeUnits(floorFinishHeightMm + floatHeightMm);
    } else {
      // 바닥에 배치: 바닥재만
      planeY = mmToThreeUnits(floorFinishHeightMm);
    }
  } else {
    // 기본값: 바닥재만
    planeY = mmToThreeUnits(floorFinishHeightMm);
  }
  
  // 내경 공간 크기
  const planeWidth = mmToThreeUnits(internalSpace.width);
  const planeDepth = mmToThreeUnits(internalSpace.depth - 10); // 받침대와 겹치지 않도록 50mm 줄임
  
  // 기준면을 벽면에서 시작하도록 z 위치 조정
  const planeZ = mmToThreeUnits(-40); // 줄인 깊이의 절반만큼 뒤로 이동
  
  return (
    <group position={[internalCenterXThreeUnits, planeY - 0.1, planeZ]}>
      {/* 가구 배치 기준면 - 초록색 반투명 (Z-fighting 방지를 위해 0.1 단위 아래로, 내경 중심에 배치) */}
      <Plane
        args={[planeWidth, planeDepth]}
        rotation={[-Math.PI / 2, 0, 0]} // 수평으로 회전
      >
        <meshBasicMaterial 
          color={isFurniturePlacementMode ? "#808080" : "#808080"} 
          transparent 
          opacity={0.3}
          side={2} // DoubleSide
        />
        
        {/* R3F 방식의 테두리 선 */}
        <Edges color={isFurniturePlacementMode ? "#808080" : "#808080"} />
      </Plane>
    </group>
  );
};

export default FurniturePlacementPlane; 