import React, { useEffect, useState } from 'react';
import { useThree } from '@react-three/fiber';
import { SpaceInfo } from '@/store/editorStore';
import { calculateSpaceIndexing } from '@/editor/shared/utils/indexing';
import { calculateInternalSpace } from '../../utils/geometry';
import { useFurnitureData, useFurnitureDrag } from '@/editor/shared/furniture/providers';
import { getModuleById } from '@/data/modules';
import { 
  getSlotIndexFromMousePosition as getSlotIndexFromRaycast,
  isDualFurniture,
  calculateSlotDimensions,
  calculateSlotStartY,
  calculateFurniturePosition
} from '../../utils/slotRaycast';

interface SlotDropZonesProps {
  spaceInfo: SpaceInfo;
}

// 전역 window 타입 확장
declare global {
  interface Window {
    handleSlotDrop?: (dragEvent: DragEvent, canvasElement: HTMLCanvasElement) => boolean;
  }
}

const SlotDropZones: React.FC<SlotDropZonesProps> = ({ spaceInfo }) => {
  const { addModule, placedModules, removeModule } = useFurnitureData();
  const { currentDragData, setCurrentDragData } = useFurnitureDrag();
  
  // Three.js 컨텍스트 접근
  const { camera, scene } = useThree();
  
  // 마우스가 hover 중인 슬롯 인덱스 상태
  const [hoveredSlotIndex, setHoveredSlotIndex] = useState<number | null>(null);
  
  // 내경 공간 및 인덱싱 계산
  const internalSpace = calculateInternalSpace(spaceInfo);
  const indexing = calculateSpaceIndexing(spaceInfo);
  
  // 슬롯에 있는 기존 가구들을 찾아서 삭제하는 함수
  const removeExistingFurnitureInSlots = React.useCallback((targetSlot: number, isDualFurniture: boolean): void => {
    const targetSlots = isDualFurniture 
      ? [targetSlot, targetSlot + 1] 
      : [targetSlot];
    
    const furnitureToRemove: string[] = [];
    
    placedModules.forEach(placedModule => {
      const moduleData = getModuleById(placedModule.moduleId, internalSpace, spaceInfo);
      if (!moduleData) return;
      
      const isModuleDual = Math.abs(moduleData.dimensions.width - (indexing.columnWidth * 2)) < 50;
      
      // 기존 모듈의 슬롯 찾기
      let moduleSlot = -1;
      if (isModuleDual && indexing.threeUnitDualPositions) {
        moduleSlot = indexing.threeUnitDualPositions.findIndex((pos: number) => 
          Math.abs(pos - placedModule.position.x) < 0.1
        );
      } else {
        moduleSlot = indexing.threeUnitPositions.findIndex((pos: number) => 
          Math.abs(pos - placedModule.position.x) < 0.1
        );
      }
      
      if (moduleSlot >= 0) {
        const moduleSlots = isModuleDual ? [moduleSlot, moduleSlot + 1] : [moduleSlot];
        const hasOverlap = targetSlots.some(slot => moduleSlots.includes(slot));
        
        if (hasOverlap) {
          furnitureToRemove.push(placedModule.id);
        }
      }
    });
    
    // 찾은 가구들 삭제
    furnitureToRemove.forEach(id => {
      removeModule(id);
    });
  }, [placedModules, internalSpace, spaceInfo, indexing, removeModule]);
  
  // 드롭 처리 함수
  const handleSlotDrop = React.useCallback((dragEvent: DragEvent, canvasElement: HTMLCanvasElement): boolean => {
    if (!currentDragData) return false;
    
    // HTML5 드래그 데이터 가져오기
    let dragData;
    try {
      const dragDataString = dragEvent.dataTransfer?.getData('application/json');
      if (!dragDataString) {
        return false;
      }
      dragData = JSON.parse(dragDataString);
    } catch (error) {
      console.error('Error parsing drag data:', error);
      return false;
    }
    
    if (!dragData || dragData.type !== 'furniture') {
      return false;
    }
    
    // 레이캐스팅으로 슬롯 인덱스 찾기
    const slotIndex = getSlotIndexFromRaycast(
      dragEvent.clientX, 
      dragEvent.clientY, 
      canvasElement,
      camera,
      scene,
      spaceInfo
    );
    
    if (slotIndex === null) {
      return false;
    }
    
    // 듀얼/싱글 가구 판별
    const isDual = isDualFurniture(dragData.moduleData.id, spaceInfo);
       
    // 슬롯 충돌 검사
    removeExistingFurnitureInSlots(slotIndex, isDual);
    
    // 최종 위치 계산
    const finalX = calculateFurniturePosition(slotIndex, dragData.moduleData.id, spaceInfo);
    if (finalX === null) {
      return false;
    }
    
    // 고유 ID 생성
    const placedId = `placed-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // 새 모듈 배치
    const newModule = {
      id: placedId,
      moduleId: dragData.moduleData.id,
      position: {
        x: finalX,
        y: 0,
        z: 0
      },
      rotation: 0,
      hasDoor: dragData.moduleData.hasDoor ?? true,
      slotIndex: slotIndex,
      isDualSlot: isDual,
      isValidInCurrentSpace: true
    };
    
    addModule(newModule);
    
    // 드래그 상태 초기화
    setCurrentDragData(null);
    
    return true;
  }, [
    currentDragData, 
    camera,
    scene,
    spaceInfo,
    removeExistingFurnitureInSlots, 
    addModule, 
    setCurrentDragData
  ]);
  
  // window 객체에 함수 노출
  useEffect(() => {
    window.handleSlotDrop = handleSlotDrop;
    
    return () => {
      delete window.handleSlotDrop;
    };
  }, [handleSlotDrop]);
  
  // 간단한 드래그오버 이벤트 핸들러 - 바닥 하이라이트용
  useEffect(() => {
    if (!currentDragData) {
      return;
    }

    const handleDragOver = (e: DragEvent) => {
      e.preventDefault(); // 드롭 허용
      const canvas = document.querySelector('canvas');
      if (!canvas) return;

      const slotIndex = getSlotIndexFromRaycast(
        e.clientX, 
        e.clientY, 
        canvas,
        camera,
        scene,
        spaceInfo
      );
      setHoveredSlotIndex(slotIndex);
    };

    const handleDragLeave = () => {
      setHoveredSlotIndex(null);
    };

    // 캔버스 컨테이너에 이벤트 리스너 추가
    const canvasContainer = document.querySelector('canvas')?.parentElement;
    if (canvasContainer) {
      canvasContainer.addEventListener('dragover', handleDragOver);
      canvasContainer.addEventListener('dragleave', handleDragLeave);
    }

    return () => {
      if (canvasContainer) {
        canvasContainer.removeEventListener('dragover', handleDragOver);
        canvasContainer.removeEventListener('dragleave', handleDragLeave);
      }
    };
  }, [currentDragData, camera, scene, spaceInfo]);
  
  // 슬롯 크기 및 위치 계산
  const slotDimensions = calculateSlotDimensions(spaceInfo);
  const slotStartY = calculateSlotStartY(spaceInfo);
  
  return (
    <group>
      {/* 레이캐스팅용 투명 콜라이더들 */}
      {indexing.threeUnitPositions.map((slotX, slotIndex) => (
        <mesh
          key={`slot-collider-${slotIndex}`}
          position={[slotX, slotStartY + slotDimensions.height / 2, 0]}
          userData={{ 
            slotIndex, 
            isSlotCollider: true,
            type: 'slot-collider'
          }}
          visible={false}
        >
          <boxGeometry args={[slotDimensions.width, slotDimensions.height, slotDimensions.depth]} />
          <meshBasicMaterial transparent opacity={0} />
        </mesh>
      ))}
      
      {/* 바닥 하이라이트 */}
      {indexing.threeUnitPositions.map((slotX, slotIndex) => {
        
        // 현재 드래그 중인 가구가 듀얼인지 확인
        let isDual = false;
        if (currentDragData) {
          isDual = isDualFurniture(currentDragData.moduleData.id, spaceInfo);
        }
        
        // 하이라이트 여부 결정
        let shouldHighlight = false;
        if (hoveredSlotIndex !== null && currentDragData) {
          if (isDual) {
            // 듀얼 가구: 현재 슬롯과 다음 슬롯 모두 하이라이트
            shouldHighlight = slotIndex === hoveredSlotIndex || slotIndex === hoveredSlotIndex + 1;
          } else {
            // 싱글 가구: 현재 슬롯만 하이라이트
            shouldHighlight = slotIndex === hoveredSlotIndex;
          }
        }
        
        if (!shouldHighlight) return null;
        
        return (
          <group key={`slot-highlight-${slotIndex}`}>
            {/* 바닥 하이라이트 - 원형으로 표시 */}
            <mesh
              position={[slotX, slotStartY, 0]}
              rotation={[-Math.PI / 2, 0, 0]} // 바닥에 평평하게
            >
              <circleGeometry args={[Math.min(slotDimensions.width, slotDimensions.depth) * 0.3, 32]} />
              <meshBasicMaterial 
                color="#00ff00" 
                transparent 
                opacity={0.3}
                side={2} // DoubleSide
              />
            </mesh>
          </group>
        );
      })}
    </group>
  );
};

export default SlotDropZones;