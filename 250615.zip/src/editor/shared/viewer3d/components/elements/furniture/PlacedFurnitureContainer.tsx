import React from 'react';
import { useEditorStore } from '@/store/editorStore';
import { useFurnitureData } from '@/editor/shared/furniture/providers';
import { useFurnitureDrag } from './hooks/useFurnitureDrag';
import { useFurnitureSelection } from './hooks/useFurnitureSelection';
import { useFurnitureCollision } from './hooks/useFurnitureCollision';
import { useFurnitureKeyboard } from './hooks/useFurnitureKeyboard';
import FurnitureItem from './FurnitureItem';

const PlacedFurnitureContainer: React.FC = () => {
  const { spaceInfo } = useEditorStore();
  const { placedModules } = useFurnitureData();
  
  // mm를 Three.js 단위로 변환
  const mmToThreeUnits = (mm: number) => mm * 0.01;
  
  // 내경 공간의 시작 높이 계산
  const floorFinishHeightMm = spaceInfo.hasFloorFinish && spaceInfo.floorFinish ? spaceInfo.floorFinish.height : 0;
  const baseFrameHeightMm = spaceInfo.baseConfig?.height || 0;
  
  // 받침대 설정에 따른 가구 시작 높이 계산
  let furnitureStartY: number;
  
  if (!spaceInfo.baseConfig || spaceInfo.baseConfig.type === 'floor') {
    // 받침대 있음: 바닥재 + 받침대 높이
    furnitureStartY = mmToThreeUnits(floorFinishHeightMm + baseFrameHeightMm);
  } else if (spaceInfo.baseConfig.type === 'stand') {
    // 받침대 없음
    if (spaceInfo.baseConfig.placementType === 'float') {
      // 띄워서 배치: 바닥재 + 띄움 높이
      const floatHeightMm = spaceInfo.baseConfig.floatHeight || 0;
      furnitureStartY = mmToThreeUnits(floorFinishHeightMm + floatHeightMm);
    } else {
      // 바닥에 배치: 바닥재만
      furnitureStartY = mmToThreeUnits(floorFinishHeightMm);
    }
  } else {
    // 기본값: 바닥재만
    furnitureStartY = mmToThreeUnits(floorFinishHeightMm);
  }

  // 커스텀 훅들 사용
  const collisionHelpers = useFurnitureCollision({ spaceInfo });
  const selectionState = useFurnitureSelection();
  const dragHandlers = useFurnitureDrag({ 
    spaceInfo, 
    removeExistingFurnitureInSlots: collisionHelpers.removeExistingFurnitureInSlots 
  });

  // 키보드 이벤트 훅 (다른 훅들의 상태를 사용)
  useFurnitureKeyboard({
    spaceInfo,
    removeExistingFurnitureInSlots: collisionHelpers.removeExistingFurnitureInSlots
  });

  return (
    <group>
      {placedModules.map((placedModule) => {
        const isDragMode = selectionState.dragMode;
        const isEditMode = selectionState.editMode && selectionState.editingModuleId === placedModule.id;
        const isDraggingThis = dragHandlers.draggingModuleId === placedModule.id;

        return (
          <FurnitureItem
            key={placedModule.id}
            placedModule={placedModule}
            spaceInfo={spaceInfo}
            furnitureStartY={furnitureStartY}
            isDragMode={isDragMode}
            isEditMode={isEditMode}
            isDraggingThis={isDraggingThis}
            onPointerDown={dragHandlers.handlePointerDown}
            onPointerMove={dragHandlers.handlePointerMove}
            onPointerUp={dragHandlers.handlePointerUp}
            onDoubleClick={selectionState.handleFurnitureClick}
          />
        );
      })}
    </group>
  );
};

export default PlacedFurnitureContainer; 