import { useState, useRef } from 'react';
import { ThreeEvent } from '@react-three/fiber';
import { useFurnitureUI, useFurnitureData } from '@/editor/shared/furniture/providers';

export const useFurnitureSelection = () => {
  const { editMode, editingModuleId, setEditMode, setEditingModuleId } = useFurnitureUI();
  const { removeModule } = useFurnitureData();
  const [dragMode, setDragMode] = useState(false);
  const isDragging = useRef(false);

  // 가구 클릭 핸들러 (원클릭 편집모드)
  const handleFurnitureClick = (e: ThreeEvent<MouseEvent>, placedModuleId: string) => {
    // 드래그였다면 클릭 이벤트 무시
    if (isDragging.current) return;
    
    e.stopPropagation();
    
    if (dragMode) {
      // 드래그 모드에서는 삭제
      removeModule(placedModuleId);
      setDragMode(false);
    } else {
      // 가구 클릭하면 바로 편집모드 진입 (이미 편집 중이어도 해당 가구로 편집모드 전환)
      setEditMode(true);
      setEditingModuleId(placedModuleId);
    }
  };

  return {
    dragMode,
    setDragMode,
    editMode,
    setEditMode,
    editingModuleId,
    setEditingModuleId,
    handleFurnitureClick,
    isDragging
  };
}; 