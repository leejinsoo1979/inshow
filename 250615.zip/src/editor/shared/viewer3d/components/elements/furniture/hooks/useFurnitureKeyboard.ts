import { useEffect } from 'react';
import { useFurnitureData, useFurnitureUI } from '@/editor/shared/furniture/providers';
import { getModuleById } from '@/data/modules';
import { calculateSpaceIndexing } from '@/editor/shared/utils/indexing';
import { calculateInternalSpace } from '../../../../utils/geometry';
import { SpaceInfo } from '@/store/editorStore';

interface UseFurnitureKeyboardProps {
  spaceInfo: SpaceInfo;
  removeExistingFurnitureInSlots: (targetSlot: number, isDualFurniture: boolean, excludeModuleId: string) => void;
}

export const useFurnitureKeyboard = ({
  spaceInfo,
  removeExistingFurnitureInSlots
}: UseFurnitureKeyboardProps) => {
  const { placedModules, removeModule, moveModule } = useFurnitureData();
  const { editMode, editingModuleId, setEditMode, setEditingModuleId } = useFurnitureUI();
  
  // 내경 공간 계산
  const internalSpace = calculateInternalSpace(spaceInfo);
  const indexing = calculateSpaceIndexing(spaceInfo);

  // 키보드 이벤트 처리
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!editMode || !editingModuleId) return;
      
      const editingModule = placedModules.find(m => m.id === editingModuleId);
      if (!editingModule) return;
      
      // 편집 중인 가구의 데이터 가져오기
      const moduleData = getModuleById(editingModule.moduleId, internalSpace, spaceInfo);
      if (!moduleData) return;
      
      // 듀얼/싱글 가구 판별
      const columnWidth = indexing.columnWidth;
      const isDualFurniture = Math.abs(moduleData.dimensions.width - (columnWidth * 2)) < 50;
      
      let currentSlotIndex = -1;
      
      if (isDualFurniture) {
        // 듀얼 가구: threeUnitDualPositions에서 슬롯 찾기
        if (indexing.threeUnitDualPositions) {
          currentSlotIndex = indexing.threeUnitDualPositions.findIndex(pos => 
            Math.abs(pos - editingModule.position.x) < 0.1
          );
        }
      } else {
        // 싱글 가구: threeUnitPositions에서 슬롯 찾기
        currentSlotIndex = indexing.threeUnitPositions.findIndex(pos => 
          Math.abs(pos - editingModule.position.x) < 0.1
        );
      }
      
      if (currentSlotIndex === -1) {
        return;
      }
      
      let newSlotIndex = currentSlotIndex;
      
      switch (e.key) {
        case 'Delete':
        case 'Backspace':
          removeModule(editingModuleId);
          setEditMode(false);
          setEditingModuleId(null);
          e.preventDefault();
          break;
          
        case 'ArrowLeft':
          newSlotIndex = Math.max(0, currentSlotIndex - 1);
          if (newSlotIndex !== currentSlotIndex) {
            // 목표 슬롯의 기존 가구 삭제
            const moduleData = getModuleById(editingModule.moduleId, internalSpace, spaceInfo);
            if (moduleData) {
              const columnWidth = indexing.columnWidth;
              const isMovingDual = Math.abs(moduleData.dimensions.width - (columnWidth * 2)) < 50;
              removeExistingFurnitureInSlots(newSlotIndex, isMovingDual, editingModuleId);
            }
            
            let newX: number;
            if (isDualFurniture && indexing.threeUnitDualPositions) {
              newX = indexing.threeUnitDualPositions[newSlotIndex];
            } else {
              newX = indexing.threeUnitPositions[newSlotIndex];
            }
            moveModule(editingModuleId, { ...editingModule.position, x: newX });
          }
          e.preventDefault();
          break;
          
        case 'ArrowRight': {
          const maxSlotIndex = isDualFurniture && indexing.threeUnitDualPositions 
            ? indexing.threeUnitDualPositions.length - 1 
            : indexing.threeUnitPositions.length - 1;
          
          newSlotIndex = Math.min(maxSlotIndex, currentSlotIndex + 1);
          if (newSlotIndex !== currentSlotIndex) {
            // 목표 슬롯의 기존 가구 삭제
            const moduleData = getModuleById(editingModule.moduleId, internalSpace, spaceInfo);
            if (moduleData) {
              const columnWidth = indexing.columnWidth;
              const isMovingDual = Math.abs(moduleData.dimensions.width - (columnWidth * 2)) < 50;
              removeExistingFurnitureInSlots(newSlotIndex, isMovingDual, editingModuleId);
            }
            
            let newX: number;
            if (isDualFurniture && indexing.threeUnitDualPositions) {
              newX = indexing.threeUnitDualPositions[newSlotIndex];
            } else {
              newX = indexing.threeUnitPositions[newSlotIndex];
            }
            moveModule(editingModuleId, { ...editingModule.position, x: newX });
          }
          e.preventDefault();
          break;
        }
          
        case 'Escape':
          setEditMode(false);
          setEditingModuleId(null);
          e.preventDefault();
          break;
          
        case 'Enter':
          setEditMode(false);
          setEditingModuleId(null);
          e.preventDefault();
          break;
      }
    };
    
    if (editMode) {
      document.addEventListener('keydown', handleKeyDown);
      return () => {
        document.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [editMode, editingModuleId, placedModules, indexing, removeModule, moveModule, internalSpace, spaceInfo, removeExistingFurnitureInSlots, setEditMode, setEditingModuleId]);
}; 