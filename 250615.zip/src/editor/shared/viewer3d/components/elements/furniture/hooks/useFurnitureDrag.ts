import { useState, useRef } from 'react';
import { ThreeEvent } from '@react-three/fiber';
import { useThree } from '@react-three/fiber';
import { useFurnitureData, useFurnitureUI } from '@/editor/shared/furniture/providers';
import { getModuleById } from '@/data/modules';
import { calculateSpaceIndexing } from '@/editor/shared/utils/indexing';
import { calculateInternalSpace } from '../../../../utils/geometry';
import { SpaceInfo } from '@/store/editorStore';
import { getSlotIndexFromMousePosition as getSlotIndexFromRaycast } from '../../../../utils/slotRaycast';

interface UseFurnitureDragProps {
  spaceInfo: SpaceInfo;
  removeExistingFurnitureInSlots: (targetSlot: number, isDualFurniture: boolean, excludeModuleId: string) => void;
}

export const useFurnitureDrag = ({ spaceInfo, removeExistingFurnitureInSlots }: UseFurnitureDragProps) => {
  const { placedModules, moveModule } = useFurnitureData();
  const { setFurniturePlacementMode } = useFurnitureUI();
  const [draggingModuleId, setDraggingModuleId] = useState<string | null>(null);
  const isDragging = useRef(false);
  
  // Three.js 컨텍스트 접근
  const { camera, scene } = useThree();
  
  // 내경 공간 계산
  const internalSpace = calculateInternalSpace(spaceInfo);



  // 드래그 시작
  const handlePointerDown = (e: ThreeEvent<PointerEvent>, placedModuleId: string) => {
    console.log('🖱️ 드래그 시작:', placedModuleId, 'button:', e.button);
    
    // 왼쪽 버튼이 아니면 드래그 시작하지 않음 (오른쪽 버튼은 OrbitControls 회전용)
    if (e.button !== 0) {
      console.log('❌ 왼쪽 버튼이 아님, 드래그 취소');
      return;
    }
    
    e.stopPropagation();
    
    setDraggingModuleId(placedModuleId);
    isDragging.current = true;
    
    console.log('✅ 드래그 상태 설정 완료:', { draggingModuleId: placedModuleId, isDragging: isDragging.current });
    
    // 가구 배치 모드 활성화
    setFurniturePlacementMode(true);
    
    // 포인터 캡처
    const target = e.target as Element & { setPointerCapture?: (pointerId: number) => void };
    if (target && target.setPointerCapture) {
      target.setPointerCapture(e.pointerId);
      console.log('📌 포인터 캡처 설정');
    }
    
    document.body.style.cursor = 'grabbing';
  };

  // 드래그 중 처리
  const handlePointerMove = (event: ThreeEvent<PointerEvent>) => {
    if (!isDragging.current || !draggingModuleId) return;

    // 공통 레이캐스팅 유틸리티 사용
    const canvas = event.nativeEvent.target as HTMLCanvasElement;
    const slotIndex = getSlotIndexFromRaycast(
      event.nativeEvent.clientX, 
      event.nativeEvent.clientY, 
      canvas,
      camera,
      scene,
      spaceInfo
    );
    
    console.log('🎯 드래그 중 레이캐스팅:', { 
      mouseX: event.nativeEvent.clientX, 
      mouseY: event.nativeEvent.clientY, 
      detectedSlot: slotIndex 
    });
    
    if (slotIndex !== null) {
      console.log('✅ 슬롯 감지됨:', slotIndex);
      
      // 현재 드래그 중인 모듈 정보 가져오기
      const currentModule = placedModules.find(m => m.id === draggingModuleId);
      if (!currentModule) return;

      const moduleData = getModuleById(currentModule.moduleId, internalSpace, spaceInfo);
      if (!moduleData) return;

      // 듀얼/싱글 가구 판별
      const indexing = calculateSpaceIndexing(spaceInfo);
      const columnWidth = indexing.columnWidth;
      const isDualFurniture = Math.abs(moduleData.dimensions.width - (columnWidth * 2)) < 50;

      // 슬롯 충돌 검사 (자기 자신 제외)
      removeExistingFurnitureInSlots(slotIndex, isDualFurniture, draggingModuleId);

      // 최종 위치 계산
      let finalX: number;
      if (isDualFurniture) {
        if (indexing.threeUnitDualPositions && indexing.threeUnitDualPositions[slotIndex] !== undefined) {
          finalX = indexing.threeUnitDualPositions[slotIndex];
        } else {
          return; // 듀얼 위치가 없으면 이동하지 않음
        }
      } else {
        finalX = indexing.threeUnitPositions[slotIndex];
      }

      console.log('📍 가구 이동:', { 
        slotIndex, 
        finalX, 
        currentX: currentModule.position.x,
        isDualFurniture 
      });

      // 모듈 위치 업데이트
      moveModule(draggingModuleId, {
        x: finalX,
        y: currentModule.position.y,
        z: currentModule.position.z
      });
    } else {
      console.log('❌ 슬롯 감지 실패');
    }
  };

  // 드래그 종료
  const handlePointerUp = () => {
    if (isDragging.current) {
      isDragging.current = false;
      setDraggingModuleId(null);
      setFurniturePlacementMode(false);
    }
  };

  return {
    draggingModuleId,
    isDragging: isDragging.current,
    handlePointerDown,
    handlePointerMove,
    handlePointerUp
  };
}; 