import React from 'react';
import * as THREE from 'three';
import { Line } from '@react-three/drei';
import { useEditorStore } from '@/store/editorStore';
import { calculateSpaceIndexing } from '@/editor/shared/utils/indexing';
import { calculateInternalSpace } from '../../utils/geometry';
import ColumnDropTarget from './ColumnDropTarget';

/**
 * 컬럼 인덱스 가이드 라인 컴포넌트
 * step0 이후로는 모든 step에서 configurator로 통일 처리
 */
const ColumnGuides: React.FC = () => {
  const { spaceInfo } = useEditorStore();
  
  // 인덱싱 계산
  const indexing = calculateSpaceIndexing(spaceInfo);
  const { columnCount, threeUnitBoundaries } = indexing;
  
  // 1개 컬럼인 경우 가이드 표시 불필요
  if (columnCount <= 1) return null;
  
  // 내경 공간 계산 (바닥, 천장 높이 등)
  const internalSpace = calculateInternalSpace(spaceInfo);
  
  // mm를 Three.js 단위로 변환
  const mmToThreeUnits = (mm: number) => mm * 0.01;
  
  // 바닥과 천장 높이 (Three.js 단위)
  const floorY = mmToThreeUnits(internalSpace.startY);
  const ceilingY = floorY + mmToThreeUnits(internalSpace.height);
  
  // 내경의 앞뒤 좌표 (Three.js 단위)
  const frontZ = mmToThreeUnits(internalSpace.depth / 2);
  const backZ = -frontZ;
  
  // 내경 공간의 시작 높이 계산 (바닥 마감재 + 하단 프레임 높이)
  const floorFinishHeightMm = spaceInfo.hasFloorFinish && spaceInfo.floorFinish ? spaceInfo.floorFinish.height : 0;
  const baseFrameHeightMm = spaceInfo.baseConfig?.height || 0;
  const furnitureStartY = (floorFinishHeightMm + baseFrameHeightMm) * 0.01; // mm → Three.js 단위 변환
  
  return (
    <group>
      {/* 각 컬럼 경계에 가이드 라인 생성 (첫 번째와 마지막 경계는 프레임과 겹치므로 제외) */}
      {threeUnitBoundaries.slice(1, -1).map((xPos: number, index: number) => (
        <React.Fragment key={`boundary-${index + 1}`}>
          {/* 바닥 가이드 */}
          <Line
            points={[
              new THREE.Vector3(xPos, floorY, frontZ),
              new THREE.Vector3(xPos, floorY, backZ)
            ]}
            color="#4080ff"
            lineWidth={1}
            dashed
            dashSize={0.2}
            gapSize={0.1}
          />
          
          {/* 후면 수직 가이드 */}
          <Line
            points={[
              new THREE.Vector3(xPos, floorY, backZ),
              new THREE.Vector3(xPos, ceilingY, backZ)
            ]}
            color="#4080ff"
            lineWidth={1}
            dashed
            dashSize={0.2}
            gapSize={0.1}
          />
          
          {/* 천장 가이드 */}
          <Line
            points={[
              new THREE.Vector3(xPos, ceilingY, backZ),
              new THREE.Vector3(xPos, ceilingY, frontZ)
            ]}
            color="#4080ff"
            lineWidth={1}
            dashed
            dashSize={0.2}
            gapSize={0.1}
          />
          
          {/* 전면 수직 가이드 */}
          <Line
            points={[
              new THREE.Vector3(xPos, ceilingY, frontZ),
              new THREE.Vector3(xPos, floorY, frontZ)
            ]}
            color="#4080ff"
            lineWidth={1}
            dashed
            dashSize={0.2}
            gapSize={0.1}
          />
        </React.Fragment>
      ))}
      
      {/* 컬럼 인덱스 드롭 타겟 - step0 이후로는 모든 step에서 표시 */}
      {indexing.threeUnitPositions.map((x, i) => (
        <ColumnDropTarget
          key={`column-${i}`}
          columnIndex={i}
          columnWidth={indexing.columnWidth}
          position={{ x, y: furnitureStartY, z: 0 }}
          internalSpace={internalSpace}
        />
      ))}
    </group>
  );
};

export default ColumnGuides; 