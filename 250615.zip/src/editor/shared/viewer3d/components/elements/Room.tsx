import React, { useMemo } from 'react';
import * as THREE from 'three';
import { SpaceInfo } from '@/store/editorStore';
import { 
  calculateRoomDimensions, 
  calculateFloorFinishHeight,
  calculatePanelDepth,
  calculateFrameThickness,
  calculateBaseFrameWidth,
  calculateTopBottomFrameHeight,
  calculateBaseFrameHeight
} from '../../utils/geometry';
import { MaterialFactory } from '../../utils/materials/MaterialFactory';
import PlacedFurnitureContainer from './furniture/PlacedFurnitureContainer';

interface RoomProps {
  spaceInfo: SpaceInfo;
  floorColor?: string;
  viewMode?: '2D' | '3D';
  materialConfig?: {
    doorColor: string;
  };
}

// mm를 Three.js 단위로 변환 (1mm = 0.01 Three.js units)
const mmToThreeUnits = (mm: number): number => mm * 0.01;

const END_PANEL_THICKNESS = 20; // 20mm

// 2D 모드용 Box with Edges 컴포넌트 - EdgesGeometry 사용으로 일관성 확보
const BoxWithEdges: React.FC<{
  args: [number, number, number];
  position: [number, number, number];
  material: THREE.Material;
}> = ({ args, position, material }) => {
  const geometry = useMemo(() => new THREE.BoxGeometry(...args), [args]);
  
  return (
    <group position={position}>
      {/* 면 렌더링만 (모서리 라인 제거) */}
      <mesh geometry={geometry}>
        <primitive object={material} />
      </mesh>
    </group>
  );
};

const Room: React.FC<RoomProps> = ({
  spaceInfo,
  floorColor = '#FF9966',
  viewMode = '3D',
  materialConfig
}) => {
  const { width: widthMm, height: heightMm } = calculateRoomDimensions(spaceInfo);
  const floorFinishHeightMm = calculateFloorFinishHeight(spaceInfo);
  const panelDepthMm = calculatePanelDepth(spaceInfo);
  const frameThicknessMm = calculateFrameThickness(spaceInfo);
  const baseFrameMm = calculateBaseFrameWidth(spaceInfo);
  const topBottomFrameHeightMm = calculateTopBottomFrameHeight(spaceInfo);
  const baseFrameHeightMm = calculateBaseFrameHeight(spaceInfo);
  
  // mm를 Three.js 단위로 변환
  const width = mmToThreeUnits(widthMm);
  const height = mmToThreeUnits(heightMm);
  const panelDepth = mmToThreeUnits(panelDepthMm);
  const floorFinishHeight = mmToThreeUnits(floorFinishHeightMm);
  const frameThickness = {
    left: mmToThreeUnits(frameThicknessMm.left),
    right: mmToThreeUnits(frameThicknessMm.right)
  };
  const baseFrame = {
    width: mmToThreeUnits(baseFrameMm.width)
  };
  const topBottomFrameHeight = mmToThreeUnits(topBottomFrameHeightMm);
  const baseFrameHeight = mmToThreeUnits(baseFrameHeightMm);
  
  // 프레임 재질 - 문 색상과 동기화 (벽 색상은 변경하지 않음)
  const sideFrameMaterial = useMemo(() => {
    const frameColor = materialConfig?.doorColor || '#FFFFFF';  // 기본값을 흰색으로 변경 (테스트용)
    return MaterialFactory.createSolidFrameMaterial(frameColor);
  }, [materialConfig?.doorColor]);
  
  // MaterialFactory를 사용한 재질 생성 (자동 캐싱으로 성능 최적화)
  const frontToBackGradientMaterial = useMemo(() => MaterialFactory.createWallMaterial(), []);
  const horizontalGradientMaterial = useMemo(() => MaterialFactory.createWallMaterial(), []);
  const leftHorizontalGradientMaterial = useMemo(() => MaterialFactory.createWallMaterial(), []);
  
  // 2D 모드용 재질들
  const flatMaterial = useMemo(() => MaterialFactory.createFlatMaterial('#f8f8f8'), []);
  
  // viewMode에 따라 사용할 재질 결정
  const currentSideFrameMaterial = viewMode === '2D' ? flatMaterial : sideFrameMaterial;
  
  // 3D 룸 중앙 정렬을 위한 오프셋 계산
  const xOffset = -width / 2; // 가로 중앙 (전체 폭의 절반을 왼쪽으로)
  const yOffset = 0; // 바닥 기준
  const zOffset = -panelDepth / 2; // 깊이 중앙 (앞뒤 대칭)
  
  // 전체 그룹을 z축 방향으로 약간 조정 (앞으로 당겨서 중앙에 오도록)
  const groupZOffset = 0; // 필요에 따라 조정 가능 (양수: 앞으로, 음수: 뒤로)
  
  // 상단/하단 패널의 너비 (좌우 프레임 사이의 공간)
  const topBottomPanelWidth = baseFrame.width;
  
  // 노서라운드 모드일 때 이격거리를 고려한 패널 너비 계산
  const noSurroundAdjustedWidth = spaceInfo.surroundType === 'no-surround' && spaceInfo.gapConfig
    ? width - mmToThreeUnits(spaceInfo.gapConfig.size * 2) // 좌우 각각 이격거리만큼 줄임
    : topBottomPanelWidth;
    
  // 최종적으로 사용할 패널 너비
  const finalPanelWidth = spaceInfo.surroundType === 'no-surround' ? noSurroundAdjustedWidth : topBottomPanelWidth;
  
  // 패널 X 좌표 계산 (노서라운드일 때는 중앙 정렬)
  const topBottomPanelX = spaceInfo.surroundType === 'no-surround' 
    ? xOffset + width/2 // 중앙 정렬
    : xOffset + frameThickness.left + topBottomPanelWidth / 2;

  // 바닥재료가 있을 때 좌우 패널의 시작 Y 위치와 높이 조정
  const panelStartY = spaceInfo.hasFloorFinish && floorFinishHeight > 0 ? floorFinishHeight : 0;
  
  // 띄워서 배치일 때 높이 조정
  const floatHeight = spaceInfo.baseConfig?.type === 'stand' && spaceInfo.baseConfig?.placementType === 'float' 
    ? mmToThreeUnits(spaceInfo.baseConfig.floatHeight || 0) 
    : 0;
  
  // 좌우 프레임 높이 (띄워서 배치일 때 줄어듦)
  const adjustedPanelHeight = height - floatHeight;
  
  // 상단 요소들의 Y 위치 (띄워서 배치일 때 위로 이동)
  const topElementsY = panelStartY + height - topBottomFrameHeight/2;
  
  // 좌우 프레임의 시작 Y 위치 (띄워서 배치일 때 위로 이동)
  const sideFrameStartY = panelStartY + floatHeight;
  const sideFrameCenterY = sideFrameStartY + adjustedPanelHeight/2;

  // 벽 여부 확인
  const { wallConfig } = spaceInfo;

  return (
    <group position={[0, 0, groupZOffset]}>
      {/* 주변 벽면들 - 깊이 기반 투명도 적용 (3D 모드에서만 표시) */}
      {viewMode === '3D' && (
        <>
          {/* 왼쪽 외부 벽면 - 순수 흰색 */}
          <mesh
            position={[-width/2 - 0.001, panelStartY + height/2, zOffset + panelDepth/2]}
            rotation={[0, Math.PI / 2, 0]}
          >
            <planeGeometry args={[panelDepth, height]} />
            <meshLambertMaterial 
              color="#ffffff" 
              transparent={false}
              emissive={new THREE.Color("#ffffff")}
              emissiveIntensity={0.1}
              side={THREE.DoubleSide}
            />
          </mesh>
          
          {/* 오른쪽 외부 벽면 - 순수 흰색 */}
          <mesh
            position={[width/2 + 0.001, panelStartY + height/2, zOffset + panelDepth/2]}
            rotation={[0, -Math.PI / 2, 0]}
          >
            <planeGeometry args={[panelDepth, height]} />
            <meshLambertMaterial 
              color="#ffffff" 
              transparent={false}
              emissive={new THREE.Color("#ffffff")}
              emissiveIntensity={0.1}
              side={THREE.DoubleSide}
            />
          </mesh>
          
          {/* 상단 외부 벽면 - 순수 흰색 */}
          <mesh
            position={[xOffset + width/2, panelStartY + height + 0.001, zOffset + panelDepth/2]}
            rotation={[Math.PI / 2, 0, 0]}
          >
            <planeGeometry args={[width, panelDepth]} />
            <meshLambertMaterial 
              color="#ffffff" 
              transparent={false}
              emissive={new THREE.Color("#ffffff")}
              emissiveIntensity={0.1}
              side={THREE.DoubleSide}
            />
          </mesh>
          
          {/* 뒤쪽 외부 벽면 - 순수 흰색 */}
          <mesh
            position={[xOffset + width/2, panelStartY + height/2, zOffset - 0.01]}
          >
            <planeGeometry args={[width, height]} />
            <meshLambertMaterial 
              color="#ffffff" 
              transparent={false}
              emissive={new THREE.Color("#ffffff")}
              emissiveIntensity={0.3}
              side={THREE.DoubleSide}
            />
          </mesh>
          
          {/* 벽장 공간의 3면에서 나오는 그라데이션 오버레이들 - 입체감 효과 */}
          
          {(() => {
            const showGradients = false; // 그라디언트 면 일시적으로 숨김
            return showGradients && (
              <>
                {/* 좌측 벽면에서 나오는 그라데이션 (가구 공간 내부로 Z축 확장) */}
                <mesh
                  position={[-width/2 - 0.001, panelStartY + adjustedPanelHeight/2, zOffset + panelDepth/2 + 10.81]}
                  rotation={[0, -Math.PI / 2, 0]} // 우측과 반대 방향
                >
                  <planeGeometry args={[panelDepth + 10, adjustedPanelHeight]} />
                  <primitive object={leftHorizontalGradientMaterial} />
                </mesh>
                
                {/* 우측 벽면에서 나오는 그라데이션 (가구 공간 내부로 Z축 확장) */}
                <mesh
                  position={[width/2 + 0.001, panelStartY + adjustedPanelHeight/2, zOffset + panelDepth/2 + 10.81]}
                  rotation={[0, Math.PI / 2, 0]} // Y축 기준 시계반대방향 90도 회전
                >
                  <planeGeometry args={[panelDepth + 10, adjustedPanelHeight]} />
                  <primitive object={horizontalGradientMaterial} />
                </mesh>
                
                {/* 윗면에서 나오는 그라데이션 (가구 공간 내부로 Z축 확장) */}
                <mesh
                  position={[0, panelStartY + height + 0.001, zOffset + panelDepth/2 + 10.81]}
                  rotation={[Math.PI / 2, 0, 0]} // 윗면을 향하도록 90도 회전
                >
                  <planeGeometry args={[width, panelDepth + 10]} />
                  <primitive object={frontToBackGradientMaterial} />
                </mesh>
              </>
            );
          })()}
        </>
      )}
      
      {/* 바닥 마감재가 있는 경우 - 전체 가구 폭으로 설치 */}
      {spaceInfo.hasFloorFinish && floorFinishHeight > 0 && (
        <BoxWithEdges
          args={[width, floorFinishHeight, panelDepth]}
          position={[xOffset + width/2, yOffset + floorFinishHeight/2, zOffset + panelDepth/2]}
          material={new THREE.MeshLambertMaterial({ color: floorColor, transparent: true, opacity: 0.3 })}
        />
      )}
      
      {/* 왼쪽 프레임/엔드 패널 - 바닥재료 위에서 시작 */}
      {spaceInfo.surroundType !== 'no-surround' &&
        (spaceInfo.installType === 'built-in' || 
        spaceInfo.installType === 'semi-standing' || 
        spaceInfo.installType === 'free-standing') && (
        <BoxWithEdges
          args={[
            frameThickness.left, 
            adjustedPanelHeight, 
            // 설치 타입과 벽 여부에 따라 깊이 결정
            (spaceInfo.installType === 'semi-standing' && !wallConfig?.left) || 
            spaceInfo.installType === 'free-standing' 
              ? panelDepth  // 벽이 없는 경우 엔드패널 (580mm)
              : mmToThreeUnits(END_PANEL_THICKNESS)  // 벽이 있는 경우 프레임 (20mm)
          ]}
          position={[
            xOffset + frameThickness.left/2, 
            sideFrameCenterY, 
            // 설치 타입과 벽 여부에 따라 위치 결정
            (spaceInfo.installType === 'semi-standing' && !wallConfig?.left) || 
            spaceInfo.installType === 'free-standing' 
              ? zOffset + panelDepth/2  // 벽이 없는 경우 엔드패널 (중앙)
              : zOffset + panelDepth - mmToThreeUnits(END_PANEL_THICKNESS)/2  // 벽이 있는 경우 프레임 (앞면에서 두께의 절반만큼 뒤로)
          ]}
          material={currentSideFrameMaterial}
        />
      )}
      
      {/* 오른쪽 프레임/엔드 패널 - 바닥재료 위에서 시작 */}
      {spaceInfo.surroundType !== 'no-surround' &&
        (spaceInfo.installType === 'built-in' || 
        spaceInfo.installType === 'semi-standing' || 
        spaceInfo.installType === 'free-standing') && (
        <BoxWithEdges
          args={[
            frameThickness.right, 
            adjustedPanelHeight, 
            // 설치 타입과 벽 여부에 따라 깊이 결정
            (spaceInfo.installType === 'semi-standing' && !wallConfig?.right) || 
            spaceInfo.installType === 'free-standing' 
              ? panelDepth  // 벽이 없는 경우 엔드패널 (580mm)
              : mmToThreeUnits(END_PANEL_THICKNESS)  // 벽이 있는 경우 프레임 (20mm)
          ]}
          position={[
            xOffset + width - frameThickness.right/2, 
            sideFrameCenterY, 
            // 설치 타입과 벽 여부에 따라 위치 결정
            (spaceInfo.installType === 'semi-standing' && !wallConfig?.right) || 
            spaceInfo.installType === 'free-standing' 
              ? zOffset + panelDepth/2  // 벽이 없는 경우 엔드패널 (중앙)
              : zOffset + panelDepth - mmToThreeUnits(END_PANEL_THICKNESS)/2  // 벽이 있는 경우 프레임 (앞면에서 두께의 절반만큼 뒤로)
          ]}
          material={currentSideFrameMaterial}
        />
      )}
      
      {/* 상단 패널 - 좌우 프레임 사이에만 배치, 바닥재료 고려 */}
      <BoxWithEdges
        args={[
          finalPanelWidth, 
          topBottomFrameHeight, 
          mmToThreeUnits(END_PANEL_THICKNESS)
        ]}
        position={[
          topBottomPanelX, 
          topElementsY, 
          zOffset + panelDepth - mmToThreeUnits(END_PANEL_THICKNESS)/2 - mmToThreeUnits(30)  // 베이스 프레임과 동일한 Z축 위치
        ]}
        material={currentSideFrameMaterial}
      />
      
      {/* 하단 패널 (베이스 프레임) - 좌우 프레임 사이에만 배치, 바닥재료 위에 배치 */}
      {baseFrameHeightMm > 0 && (
        <BoxWithEdges
          args={[
            finalPanelWidth, 
            baseFrameHeight, 
            mmToThreeUnits(END_PANEL_THICKNESS)
          ]}
          position={[
            topBottomPanelX, 
            panelStartY + baseFrameHeight/2, 
            // 문짝과 간격(10mm) + 문짝 두께(20mm)를 고려하여 30mm 뒤로 이동
            zOffset + panelDepth - mmToThreeUnits(END_PANEL_THICKNESS)/2 - mmToThreeUnits(30)
          ]}
          material={currentSideFrameMaterial}
        />
      )}
      
      {/* 배치된 가구들 */}
      <PlacedFurnitureContainer />
    </group>
  );
};

export default Room; 