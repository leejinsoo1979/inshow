import { FOV_ADJUSTMENTS } from './constants';

/**
 * 밀리미터를 Three.js 단위로 변환
 * @param mm 밀리미터 값
 * @returns Three.js 단위 값
 */
export const mmToThreeUnits = (mm: number): number => mm * 0.01;

/**
 * 공간 폭에 따라 동적으로 FOV를 계산
 * @param width 공간 폭 (mm)
 * @returns 계산된 FOV 값
 */
export const calculateDynamicFOV = (width: number): number => {
  const {
    BASE_FOV,
    SMALL_WIDTH_THRESHOLD,
    MEDIUM_WIDTH_THRESHOLD,
    LARGE_WIDTH_THRESHOLD,
    SMALL_ADJUSTMENT,
    MEDIUM_ADJUSTMENT,
    LARGE_ADJUSTMENT,
    XLARGE_ADJUSTMENT,
  } = FOV_ADJUSTMENTS;

  if (width <= SMALL_WIDTH_THRESHOLD) {
    return BASE_FOV + SMALL_ADJUSTMENT;
  } else if (width <= MEDIUM_WIDTH_THRESHOLD) {
    return BASE_FOV + MEDIUM_ADJUSTMENT;
  } else if (width <= LARGE_WIDTH_THRESHOLD) {
    return BASE_FOV + LARGE_ADJUSTMENT;
  } else {
    return BASE_FOV + XLARGE_ADJUSTMENT;
  }
};

/**
 * 뷰모드에 따른 카메라 위치 계산
 * @param viewMode 뷰 모드
 * @param defaultPosition 기본 카메라 위치
 * @returns 계산된 카메라 위치
 */
export const calculateCameraPosition = (
  viewMode: '2D' | '3D',
  defaultPosition: [number, number, number]
): [number, number, number] => {
  if (viewMode === '2D') {
    return [0, 10, 30]; // 2D 모드 정면 뷰
  }
  
  // 3D 모드에서는 기본 위치 사용
  return defaultPosition;
};

/**
 * 카메라 타겟 위치 계산
 * @param spaceHeight 공간 높이
 * @returns 카메라 타겟 위치
 */
export const calculateCameraTarget = (spaceHeight: number): [number, number, number] => {
  const yCenter = mmToThreeUnits(spaceHeight * 0.5);
  return [0, yCenter, 0];
}; 