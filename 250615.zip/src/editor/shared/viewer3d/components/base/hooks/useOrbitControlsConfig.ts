import { useMemo } from 'react';
import * as THREE from 'three';
import { CAMERA_SETTINGS } from '../utils/constants';

export interface OrbitControlsConfig {
  enabled: boolean;
  target: [number, number, number];
  minPolarAngle: number;
  maxPolarAngle: number;
  enablePan: boolean;
  enableZoom: boolean;
  enableRotate: boolean;
  minDistance: number;
  maxDistance: number;
  mouseButtons: {
    LEFT: number | undefined;
    MIDDLE: number;
    RIGHT: number | undefined;
  };
  touches: {
    ONE: number | undefined;
    TWO: number;
  };
}

/**
 * OrbitControls 설정을 관리하는 훅
 * 2D 모드에서는 회전 비활성화, 줌만 허용
 * 3D 모드에서는 드래그 컨트롤과의 충돌을 피하기 위해 왼쪽 버튼은 비활성화, 오른쪽 버튼으로 회전
 * @param cameraTarget 카메라 타겟 위치
 * @param viewMode 뷰 모드 (2D 또는 3D)
 * @returns OrbitControls 설정 객체
 */
export const useOrbitControlsConfig = (
  cameraTarget: [number, number, number],
  viewMode: '2D' | '3D' = '3D'
): OrbitControlsConfig => {
  const config = useMemo(() => {
    const is2DMode = viewMode === '2D';
    
    return {
      enabled: true,
      target: cameraTarget,
      minPolarAngle: CAMERA_SETTINGS.POLAR_ANGLE_MIN,
      maxPolarAngle: CAMERA_SETTINGS.POLAR_ANGLE_MAX,
      enablePan: false, // 팬 기능 비활성화 (드래그 컨트롤과 충돌 방지)
      enableZoom: true, // 줌은 항상 허용
      enableRotate: !is2DMode, // 2D 모드에서는 회전 비활성화
      minDistance: CAMERA_SETTINGS.MIN_DISTANCE,
      maxDistance: CAMERA_SETTINGS.MAX_DISTANCE,
      mouseButtons: {
        LEFT: undefined, // 왼쪽 버튼 비활성화 (드래그 컨트롤에서 사용)
        MIDDLE: THREE.MOUSE.DOLLY, // 휠 줌은 항상 활성화
        RIGHT: is2DMode ? undefined : THREE.MOUSE.ROTATE, // 2D 모드에서는 오른쪽 버튼도 비활성화
      },
      touches: {
        ONE: undefined, // 단일 터치 비활성화 (드래그 컨트롤과 충돌 방지)
        TWO: is2DMode ? THREE.TOUCH.DOLLY_ROTATE : THREE.TOUCH.DOLLY_PAN, // 2D 모드에서는 줌만, 3D 모드에서는 줌/팬
      },
    };
  }, [cameraTarget, viewMode]);

  return config;
}; 