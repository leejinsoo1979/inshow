import React from 'react';
import { Box } from '@react-three/drei';
import * as THREE from 'three';

interface ShelfRendererProps {
  shelfCount: number;
  innerWidth: number;
  innerHeight: number;
  depth: number;
  wallThickness: number;
  material: THREE.Material;
}

/**
 * ShelfRenderer 컴포넌트
 * 
 * 다양한 선반 구성을 렌더링합니다.
 * - 1개: 싱글 2단
 * - 2개: 듀얼 2단 (중앙 칸막이 + 양쪽 선반)
 * - 6개: 싱글 7단
 * - 12개: 듀얼 7단 (중앙 칸막이 + 양쪽 각각 6개)
 */
const ShelfRenderer: React.FC<ShelfRendererProps> = ({
  shelfCount,
  innerWidth,
  innerHeight,
  depth,
  wallThickness,
  material
}) => {
  if (shelfCount === 1) {
    // 싱글 2단: 중앙에 선반 1개
    return (
      <Box
        args={[innerWidth, wallThickness, depth - wallThickness]}
        position={[0, 0, wallThickness/2]}
        material={material}
      />
    );
  }

  if (shelfCount === 2) {
    // 듀얼 2단: 양쪽 칸에 각각 선반 1개씩
    return (
      <>
        {/* 왼쪽 칸 선반 */}
        <Box
          args={[innerWidth/2 - wallThickness/2, wallThickness, depth - wallThickness]}
          position={[-innerWidth/4 - wallThickness/4, 0, wallThickness/2]}
          material={material}
        />
        
        {/* 중앙 세로 칸막이 */}
        <Box
          args={[wallThickness, innerHeight, depth - wallThickness]}
          position={[0, 0, wallThickness/2]}
          material={material}
        />
        
        {/* 오른쪽 칸 선반 */}
        <Box
          args={[innerWidth/2 - wallThickness/2, wallThickness, depth - wallThickness]}
          position={[innerWidth/4 + wallThickness/4, 0, wallThickness/2]}
          material={material}
        />
      </>
    );
  }

  if (shelfCount === 6) {
    // 싱글 7단: 6개의 중간 선반
    return (
      <>
        {Array.from({ length: 6 }, (_, i) => {
          // 7단이므로 내부 높이를 7등분해서 각 구간 사이에 선반 배치
          const sectionHeight = innerHeight / 7;
          const shelfY = -innerHeight/2 + (i + 1) * sectionHeight;
          
          return (
            <Box
              key={`shelf-${i}`}
              args={[innerWidth, wallThickness, depth - wallThickness]}
              position={[0, shelfY, wallThickness/2]}
              material={material}
            />
          );
        })}
      </>
    );
  }

  if (shelfCount === 12) {
    // 듀얼 7단: 양쪽 칸에 각각 6개씩 총 12개 선반
    return (
      <>
        {/* 중앙 세로 칸막이 */}
        <Box
          args={[wallThickness, innerHeight, depth - wallThickness]}
          position={[0, 0, wallThickness/2]}
          material={material}
        />
        
        {/* 왼쪽 칸 6개 선반 */}
        {Array.from({ length: 6 }, (_, i) => {
          const sectionHeight = innerHeight / 7;
          const shelfY = -innerHeight/2 + (i + 1) * sectionHeight;
          
          return (
            <Box
              key={`left-shelf-${i}`}
              args={[innerWidth/2 - wallThickness/2, wallThickness, depth - wallThickness]}
              position={[-innerWidth/4 - wallThickness/4, shelfY, wallThickness/2]}
              material={material}
            />
          );
        })}
        
        {/* 오른쪽 칸 6개 선반 */}
        {Array.from({ length: 6 }, (_, i) => {
          const sectionHeight = innerHeight / 7;
          const shelfY = -innerHeight/2 + (i + 1) * sectionHeight;
          
          return (
            <Box
              key={`right-shelf-${i}`}
              args={[innerWidth/2 - wallThickness/2, wallThickness, depth - wallThickness]}
              position={[innerWidth/4 + wallThickness/4, shelfY, wallThickness/2]}
              material={material}
            />
          );
        })}
      </>
    );
  }

  // 알 수 없는 shelfCount인 경우 아무것도 렌더링하지 않음
  return null;
};

export default ShelfRenderer; 