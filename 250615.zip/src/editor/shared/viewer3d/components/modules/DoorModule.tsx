import React from 'react';
import { Box } from '@react-three/drei';
import { animated, useSpring } from '@react-spring/three';
import { calculateSpaceIndexing } from '@/editor/shared/utils/indexing';
import { SpaceInfo, useEditorStore } from '@/store/editorStore';
import { useUIStore } from '@/store/uiStore';

interface DoorModuleProps {
  moduleWidth: number; // 가구 폭 (mm)
  moduleDepth: number; // 가구 깊이 (mm)
  hingePosition?: 'left' | 'right'; // 힌지 위치 (기본값: right)
  spaceInfo: SpaceInfo;
  color?: string;
}

const DoorModule: React.FC<DoorModuleProps> = ({
  moduleWidth,
  moduleDepth,
  hingePosition = 'right',
  spaceInfo,
  color
}) => {
  // Store에서 재질 설정과 도어 상태 가져오기
  const { spaceInfo: storeSpaceInfo } = useEditorStore();
  const { doorsOpen } = useUIStore();
  const materialConfig = storeSpaceInfo.materialConfig || { 
    interiorColor: '#FFFFFF', 
    doorColor: '#000000' 
  };

  // 색상 설정: color prop이 있으면 사용, 없으면 store의 도어 색상 사용
  const doorColor = color || materialConfig.doorColor;

  // 투명도 설정: 
  // 1. color prop이 있으면 불투명 (특별한 상태)
  // 2. materialConfig.doorColor가 기본값(#000000)과 다르면 불투명 (색상 팔레트에서 선택됨)
  // 3. 그 외에는 투명 (최초 배치 상태)
  const isDefaultColor = materialConfig.doorColor === '#000000';
  const opacity = color || !isDefaultColor ? 1.0 : 0.9;

  // 인덱싱 정보 계산
  const indexing = calculateSpaceIndexing(spaceInfo);
  const columnWidth = indexing.columnWidth;
  
  // 듀얼 가구인지 확인 (폭이 컬럼 너비의 2배에 가까우면 듀얼)
  const isDualFurniture = Math.abs(moduleWidth - (columnWidth * 2)) < 50;
  
  // mm를 Three.js 단위로 변환
  const mmToThreeUnits = (mm: number) => mm * 0.01;
  
  // 도어 두께 (요구사항: 20mm)
  const doorThickness = 20;
  const doorThicknessUnits = mmToThreeUnits(doorThickness);
  
  // === 문 높이 계산 ===
  // 문 높이 = 전체 공간 높이 - 바닥재 높이 (내경 공간 높이)
  const fullSpaceHeight = spaceInfo.height;
  const floorHeight = spaceInfo.hasFloorFinish ? (spaceInfo.floorFinish?.height || 0) : 0;
  const actualDoorHeight = fullSpaceHeight - floorHeight;
  const doorHeight = mmToThreeUnits(actualDoorHeight);
  
  // === 문 Y 위치 계산 (기존 작동하던 로직으로 복원) ===
  // 
  // 핵심 원리: Three.js 좌표계에서 Y=0은 바닥 기준
  // 문의 기본 위치는 Y=0 (바닥)에서 시작하여 위로 올라감
  // 
  // 조정 로직:
  // 1. 바닥재가 있으면 바닥재 높이의 절반만큼 위로 (바닥재 중심에서 시작)
  // 2. 상단 프레임과의 간격을 위해 상단 프레임 높이의 절반만큼 위로
  // 3. 받침대가 있으면 받침대 높이의 절반만큼 아래로 (받침대 공간 확보)
  //
  let doorYPosition: number;
  
  if (spaceInfo.baseConfig?.type === 'floor') {
    // 받침대 있음: 상단 프레임 높이의 절반만큼 위로 + 받침대 높이의 절반만큼 아래로 조정
    const topFrameHeight = spaceInfo.frameSize?.top || 50;
    const baseFrameHeight = spaceInfo.baseConfig.height || 65;
    doorYPosition = floorHeight > 0 
      ? mmToThreeUnits(floorHeight) / 2 + mmToThreeUnits(topFrameHeight) / 2 - mmToThreeUnits(baseFrameHeight) / 2
      : mmToThreeUnits(topFrameHeight) / 2 - mmToThreeUnits(baseFrameHeight) / 2;
  } else {
    // 받침대 없음: 상단 프레임 높이의 절반만큼 위로 조정
    const topFrameHeight = spaceInfo.frameSize?.top || 50;
    doorYPosition = floorHeight > 0 ? mmToThreeUnits(floorHeight) / 2 + mmToThreeUnits(topFrameHeight) / 2 : mmToThreeUnits(topFrameHeight) / 2;
  }
  
  // 도어 깊이는 가구 깊이에서 10mm 바깥쪽으로 나오게 (가구 몸체와 겹침 방지)
  const doorDepth = mmToThreeUnits(moduleDepth) + mmToThreeUnits(20); // 10mm 바깥쪽으로
  
  // 패널 두께 (20mm)와 힌지 위치 오프셋(10mm) 상수 정의
  const panelThickness = 20;
  const hingeOffset = panelThickness / 2; // 10mm
  const hingeOffsetUnits = mmToThreeUnits(hingeOffset);
  
  // 애니메이션 설정 - 힌지 위치에 따라 다르게 설정
  const leftDoorSpring = useSpring({
    // hingePosition이 'left'이면 반시계방향, 'right'이면 시계방향 (바깥쪽으로 열림)
    rotation: doorsOpen ? (hingePosition === 'left' ? -Math.PI / 2 : Math.PI / 2) : 0,
    config: { tension: 70, friction: 20 }
  });
  
  // 듀얼 가구용 애니메이션 설정
  const dualLeftDoorSpring = useSpring({
    rotation: doorsOpen ? -Math.PI / 2 : 0, // 왼쪽 문: 반시계방향 (바깥쪽으로)
    config: { tension: 70, friction: 20 }
  });
  
  const dualRightDoorSpring = useSpring({
    rotation: doorsOpen ? Math.PI / 2 : 0, // 오른쪽 문: 시계방향 (바깥쪽으로)
    config: { tension: 70, friction: 20 }
  });

  if (isDualFurniture) {
    // 듀얼 가구: 두 개의 문 (힌지 위치는 각 문의 바깥쪽)
    // 각 문의 폭 = (전체 폭 - 양쪽 1.5mm - 가운데 3mm) / 2
    const totalWidth = moduleWidth;
    const doorWidth = (totalWidth - 1.5 - 1.5 - 3) / 2;
    const doorWidthUnits = mmToThreeUnits(doorWidth);
    
    // 첫 번째 문 위치 (왼쪽) - 회전축을 문의 왼쪽 가장자리에서 10mm 안쪽으로 이동
    const leftDoorX = mmToThreeUnits(-totalWidth / 2 + hingeOffset + doorWidth / 2);
    // 두 번째 문 위치 (오른쪽) - 회전축을 문의 오른쪽 가장자리에서 10mm 안쪽으로 이동
    const rightDoorX = mmToThreeUnits(totalWidth / 2 - hingeOffset - doorWidth / 2);

    return (
      <group>
        {/* 왼쪽 문 - 회전축을 문의 왼쪽 가장자리에서 10mm 안쪽에 위치 */}
        <group position={[leftDoorX - doorWidthUnits/2, doorYPosition, doorDepth / 2]}>
          <animated.group rotation-y={dualLeftDoorSpring.rotation}>
            <Box
              position={[doorWidthUnits/2 - hingeOffsetUnits, 0, 0]}
              args={[doorWidthUnits, doorHeight, doorThicknessUnits]}
            >
              <meshPhysicalMaterial 
                color={doorColor}
                clearcoat={opacity}
                clearcoatRoughness={0.1}
                metalness={0.1}
                roughness={0.1}
                reflectivity={0.9}
                envMapIntensity={1.5}
                transparent={true}
                opacity={opacity}
                transmission={1.0 - opacity}
              />
            </Box>
          </animated.group>
        </group>
        
        {/* 오른쪽 문 - 회전축을 문의 오른쪽 가장자리에서 10mm 안쪽에 위치 */}
        <group position={[rightDoorX + doorWidthUnits/2, doorYPosition, doorDepth / 2]}>
          <animated.group rotation-y={dualRightDoorSpring.rotation}>
            <Box
              position={[-doorWidthUnits/2 + hingeOffsetUnits, 0, 0]}
              args={[doorWidthUnits, doorHeight, doorThicknessUnits]}
            >
              <meshPhysicalMaterial 
                color={doorColor}
                clearcoat={opacity}
                clearcoatRoughness={0.1}
                metalness={0.1}
                roughness={0.1}
                reflectivity={0.9}
                envMapIntensity={1.5}
                transparent={true}
                opacity={opacity}
                transmission={1.0 - opacity}
              />
            </Box>
          </animated.group>
        </group>
      </group>
    );
  } else {
    // 싱글 가구: 하나의 문 - 힌지 위치에 따라 회전축을 문의 가장자리에서 10mm 안쪽으로 이동
    // 문의 폭 = 전체 폭 - 양쪽 1.5mm
    const doorWidth = moduleWidth - 1.5 - 1.5;
    const doorWidthUnits = mmToThreeUnits(doorWidth);
    
    if (hingePosition === 'left') {
      // 왼쪽 힌지: 회전축을 문의 왼쪽 가장자리에서 10mm 안쪽에 위치
      // 문(Box)의 x좌표를 패널 바깥쪽 끝에 오도록 조정 (닫힐 때 두 문이 딱 붙게)
      return (
        <group position={[-mmToThreeUnits(moduleWidth)/2 + hingeOffsetUnits, doorYPosition, doorDepth / 2]}>
          <animated.group rotation-y={leftDoorSpring.rotation}>
            <Box
              position={[doorWidthUnits/2 - hingeOffsetUnits, 0, 0]}
              args={[doorWidthUnits, doorHeight, doorThicknessUnits]}
            >
              <meshPhysicalMaterial 
                color={doorColor}
                clearcoat={opacity}
                clearcoatRoughness={0.1}
                metalness={0.3}
                roughness={0.1}
                reflectivity={0.9}
                envMapIntensity={1.5}
                transparent={true}
                opacity={opacity}
                transmission={1.0 - opacity}
              />
            </Box>
          </animated.group>
        </group>
      );
    } else {
      // 오른쪽 힌지: 회전축을 문의 오른쪽 가장자리에서 10mm 안쪽에 위치
      // 문(Box)의 x좌표를 패널 바깥쪽 끝에 오도록 조정 (닫힐 때 두 문이 딱 붙게)
      return (
        <group position={[mmToThreeUnits(moduleWidth)/2 - hingeOffsetUnits, doorYPosition, doorDepth / 2]}>
          <animated.group rotation-y={leftDoorSpring.rotation}>
            <Box
              position={[-doorWidthUnits/2 + hingeOffsetUnits, 0, 0]}
              args={[doorWidthUnits, doorHeight, doorThicknessUnits]}
            >
              <meshPhysicalMaterial 
                color={doorColor}
                clearcoat={opacity}
                clearcoatRoughness={0.1}
                metalness={0.3}
                roughness={0.1}
                reflectivity={0.9}
                envMapIntensity={1.5}
                transparent={true}
                opacity={opacity}
                transmission={1.0 - opacity}
              />
            </Box>
          </animated.group>
        </group>
      );
    }
  }
};

export default DoorModule; 