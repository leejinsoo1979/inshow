import React from 'react';
import { Box } from '@react-three/drei';
import { ModuleData } from '@/data/modules';
import { SpaceInfo, useEditorStore } from '@/store/editorStore';
import DoorModule from './DoorModule';
import ShelfRenderer from './ShelfRenderer';
import * as THREE from 'three';

interface BoxModuleProps {
  moduleData: ModuleData;
  color?: string;
  isDragging?: boolean;
  internalHeight?: number; // 내경 높이 추가
  hasDoor?: boolean; // 도어 유무
  customDepth?: number; // 사용자 정의 깊이 (mm)
  hingePosition?: 'left' | 'right'; // 힌지 위치
  spaceInfo?: SpaceInfo; // 인덱싱 계산을 위한 공간 정보
}

// mm를 Three.js 단위로 변환
const mmToThreeUnits = (mm: number) => mm * 0.01;

/**
 * BoxModule 컴포넌트
 * 
 * 앞면이 열린 박스형 가구를 렌더링합니다.
 * 20mm 두께의 판재로 구성된 육면체 형태의 가구로, 
 * 외부 치수는 컬럼 너비에 맞춰 동적으로 조정됩니다.
 */
const BoxModule: React.FC<BoxModuleProps> = ({
  moduleData,
  color,
  isDragging = false,
  internalHeight,
  hasDoor,
  customDepth,
  hingePosition = 'right',
  spaceInfo
}) => {
  // Store에서 재질 설정 가져오기
  const { spaceInfo: storeSpaceInfo } = useEditorStore();
  const materialConfig = storeSpaceInfo.materialConfig || { 
    interiorColor: '#FFFFFF', 
    doorColor: '#000000' 
  };

  // 모듈 설정 데이터 가져오기
  const modelConfig = moduleData.modelConfig || {
    wallThickness: 20, // 기본 20mm
    hasOpenFront: true,
    hasShelf: false,
    shelfCount: 0
  };
  
  // 판재 두께 변환 (mm -> Three.js 단위)
  const wallThickness = mmToThreeUnits(modelConfig.wallThickness || 20);
  
  // 가구 치수 변환 (mm -> Three.js 단위)
  const width = mmToThreeUnits(moduleData.dimensions.width);
  // 내경 높이가 제공되면 사용, 아니면 모듈 높이 사용
  const height = mmToThreeUnits(internalHeight || moduleData.dimensions.height);
  // 깊이: customDepth가 있으면 사용, 없으면 기본 깊이 사용
  const actualDepthMm = customDepth || moduleData.dimensions.depth;
  const depth = mmToThreeUnits(actualDepthMm);
  
  // 내부 공간 계산
  const innerWidth = width - (wallThickness * 2);
  const innerHeight = height - (wallThickness * 2);
  
  // 색상 설정: color prop이 있으면 특별한 상태, 없으면 MaterialPanel 색상 사용
  const isSpecialState = !!color;
  const materialColor = isSpecialState ? color : materialConfig.interiorColor;
  // 도어 색상: 특별한 상태일 때만 전달, 기본 상태일 때는 undefined로 전달하여 투명도 적용
  const doorColorToPass = isSpecialState ? color : undefined;
  
  // 드래깅 중이거나 배치된 상태에 따른 재질 설정
  const material = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(materialColor),
    clearcoat: 0.8,
    clearcoatRoughness: 0.2,
    metalness: 0.1,
    roughness: 0.2,
    reflectivity: 0.8,
    transparent: isDragging,
    opacity: isDragging ? 0.8 : 1.0
  });
  
  return (
    <group>
      {/* 왼쪽 측면 판재 */}
      <Box
        args={[wallThickness, height, depth]}
        position={[-width/2 + wallThickness/2, 0, 0]}
        material={material}
      />
      
      {/* 오른쪽 측면 판재 */}
      <Box
        args={[wallThickness, height, depth]}
        position={[width/2 - wallThickness/2, 0, 0]}
        material={material}
      />
      
      {/* 상단 판재 */}
      <Box
        args={[innerWidth, wallThickness, depth]}
        position={[0, height/2 - wallThickness/2, 0]}
        material={material}
      />
      
      {/* 하단 판재 */}
      <Box
        args={[innerWidth, wallThickness, depth]}
        position={[0, -height/2 + wallThickness/2, 0]}
        material={material}
      />
      
      {/* 뒷면 판재 */}
      <Box
        args={[innerWidth, innerHeight, wallThickness]}
        position={[0, 0, -depth/2 + wallThickness/2]}
        material={material}
      />
      
      {/* 중간 선반 렌더링 */}
      {modelConfig.hasShelf && modelConfig.shelfCount && (
        <ShelfRenderer
          shelfCount={modelConfig.shelfCount}
          innerWidth={innerWidth}
          innerHeight={innerHeight}
          depth={depth}
          wallThickness={wallThickness}
          material={material}
        />
      )}
      
      {/* 도어 렌더링 */}
      {hasDoor && spaceInfo && (
        <DoorModule
          moduleWidth={moduleData.dimensions.width}
          moduleDepth={actualDepthMm}
          hingePosition={hingePosition}
          spaceInfo={spaceInfo}
          color={doorColorToPass}
        />
      )}
    </group>
  );
};

export default BoxModule; 