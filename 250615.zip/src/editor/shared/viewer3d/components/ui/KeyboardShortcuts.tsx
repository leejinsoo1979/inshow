import React, { useState } from 'react';
import styles from './KeyboardShortcuts.module.css';

/**
 * 키보드 단축키 안내 컴포넌트
 * 뷰어 하단 중앙에 2단 그리드로 표시됩니다.
 */
const KeyboardShortcuts: React.FC = () => {
  const [isVisible, setIsVisible] = useState(true);
  
  const shortcuts = [
    { action: '가구 이동/삭제', key: '더블클릭', description: '마우스 클릭' },
    { action: '가구 이동', key: '왼쪽 드래그', description: '왼쪽버튼 드래그' },
    { action: '가구 회전', key: '오른쪽 드래그', description: '오른쪽버튼 드래그' },
    { action: '가구 이동', key: '←/→', description: '좌/우 방향키' },
    { action: '가구 삭제', key: 'Del', description: '선택된 가구 삭제' },
    { action: '가구 이동/삭제 종료', key: 'Esc', description: 'Esc키 누르기' }
  ];

  const handleClose = () => {
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.shortcutsPanel}>
      <div className={styles.header}>
        <div className={styles.title}>단축키 안내</div>
        <button 
          className={styles.closeButton}
          onClick={handleClose}
          aria-label="단축키 안내 닫기"
        >
          ×
        </button>
      </div>
      <div className={styles.shortcuts}>
        {shortcuts.map((shortcut, index) => (
          <div key={index} className={styles.shortcutItem}>
            <span className={styles.key}>{shortcut.key}</span>
            <span className={styles.description}>{shortcut.action}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default KeyboardShortcuts; 