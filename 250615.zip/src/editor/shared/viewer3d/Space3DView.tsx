import React, { useEffect, useMemo } from 'react';
import { Space3DViewProps } from './types';
import { Space3DViewProvider } from './context/Space3DViewContext';
import ThreeCanvas from './components/base/ThreeCanvas';
import Room from './components/elements/Room';
import PlacedFurniture from './components/elements/furniture';
import ColumnGuides from './components/elements/ColumnGuides';

import FurniturePlacementPlane from './components/elements/FurniturePlacementPlane';
import SlotDropZones from './components/elements/SlotDropZones';
import KeyboardShortcuts from './components/ui/KeyboardShortcuts';
import { useLocation } from 'react-router-dom';
import { useEditorStore } from '@/store/editorStore';
import { useUIStore } from '@/store/uiStore';
import { Environment } from '@react-three/drei';

/**
 * Space3DView 컴포넌트
 * 공간 정보를 3D로 표시하는 Three.js 뷰어
 * 2D 모드에서는 orthographic 카메라로 정면 뷰 제공
 */
const Space3DView: React.FC<Space3DViewProps> = (props) => {
  const { spaceInfo, svgSize, viewMode = '3D' } = props;
  const location = useLocation();
  const { spaceInfo: storeSpaceInfo, resetMaterialConfig } = useEditorStore();
  const { doorsOpen, toggleDoors } = useUIStore();
  
  // 컴포넌트 마운트시 재질 설정 초기화 (도어 색상을 검정색으로)
  useEffect(() => {
    resetMaterialConfig();
  }, [resetMaterialConfig]);
  
  // 재질 설정 가져오기
  const materialConfig = storeSpaceInfo.materialConfig || { 
    interiorColor: '#FFFFFF', 
    doorColor: '#FFFFFF'  // 기본값도 흰색으로 변경 (테스트용)
  };
  
  // 공간 크기에 따른 적절한 카메라 위치 계산 (mm 단위를 Three.js 단위로 변환)
  const mmToThreeUnits = (mm: number) => mm * 0.01;
  const cameraX = 0; // 가로 중앙
  const cameraY = mmToThreeUnits(spaceInfo.height * 0.5); // 높이의 절반 (정중앙을 바라보기 위함)
  
  // 폭이 매우 긴 가구도 잘 보이도록 로직 개선
  // 폭이 작을 때는 가까이, 폭이 클 때는 더 작은 배율 적용
  const getOptimalCameraDistance = () => {
    const width = spaceInfo.width;
    
    // 폭 구간별로 다른 배율 적용
    if (width <= 1200) {
      return mmToThreeUnits(width * 1.5); // 폭이 작을 때는 1.5배
    } else if (width <= 2400) {
      return mmToThreeUnits(width * 1.3); // 중간 폭일 때는 1.3배
    } else if (width <= 3600) {
      return mmToThreeUnits(width * 1.1); // 중간 폭일 때는 1.1배  
    } else {
      // 폭이 클 때는 더 작은 배율을 적용하고, 최대값 제한
      return mmToThreeUnits(850 + width * 0.3); // 기본값 + 폭의 0.3배
    }
  };
  
  const cameraZ = getOptimalCameraDistance();
  
  // 성능 개선을 위해 카메라 위치를 메모이제이션
  const cameraPosition = useMemo(() => [cameraX, cameraY, cameraZ] as [number, number, number], [cameraX, cameraY, cameraZ]);
  
  // 각 위치별 고유한 키를 생성하여 라우터 전환 시만 재렌더링
  const viewerKey = useMemo(() => `${location.pathname}-${viewMode}`, [location.pathname, viewMode]);
  
  // 드롭 이벤트 핸들러
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Canvas 요소 찾기
    const canvas = e.currentTarget.querySelector('canvas');
    if (!canvas) {
      return;
    }

    // SlotDropZones에서 노출한 함수 호출
    const handleSlotDrop = window.handleSlotDrop;
    if (typeof handleSlotDrop === 'function') {
      handleSlotDrop(e.nativeEvent, canvas);
    }
  };
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault(); // 드롭 허용
  };
  
  // 컴포넌트 언마운트 시 정리
  useEffect(() => {
    return () => {
      // 컴포넌트 언마운트 시 캔버스 정리
      const cleanupCanvases = () => {
        const canvases = document.querySelectorAll('canvas');
        canvases.forEach(canvas => {
          // 2D 컨텍스트를 사용하여 캔버스 지우기
          const ctx = canvas.getContext('2d');
          if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
          
          // WebGL 컨텍스트 정리
          const gl = canvas.getContext('webgl') || canvas.getContext('webgl2');
          if (gl) {
            try {
              // 타입 안전하게 WebGL 컨텍스트 손실 처리
              const ext = gl.getExtension('WEBGL_lose_context');
              if (ext) {
                ext.loseContext();
              }
            } catch (e) {
              console.log('WebGL context cleanup error:', e);
            }
          }
        });
      };
      
      cleanupCanvases();
    };
  }, []);
  
  return (
    <Space3DViewProvider spaceInfo={spaceInfo} svgSize={svgSize}>
      <div 
        key={viewerKey}
        style={{ 
          width: '100%', 
          height: '100%', 
          minHeight: '400px',
          position: 'relative'
        }}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        {/* 문 제어 버튼 */}
        <div style={{
          position: 'absolute',
          top: '16px',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 1000
        }}>
          <button
            onClick={toggleDoors}
            style={{
              background: 'rgba(255, 255, 255, 0.9)',
              border: '1px solid #ddd',
              borderRadius: '8px',
              padding: '8px 16px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              color: '#333',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              transition: 'all 0.2s ease'
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 1)';
              e.currentTarget.style.transform = 'translateY(-1px)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.9)';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            🚪 {doorsOpen ? '문 닫기' : '문 열기'}
          </button>
        </div>
        <ThreeCanvas 
          cameraPosition={cameraPosition}
          viewMode={viewMode}
        >
          <React.Suspense fallback={null}>
            {/* 조명 설정 */}
            <ambientLight intensity={0.4} color="#ffffff" />
            
            {/* 좌우 대칭 조명 - x축 원점 중심으로 균등하게 배치 */}
            <directionalLight 
              position={[-5, 10, 5]} 
              intensity={0.7} 
              color="#ffffff"
              castShadow
            />
            <directionalLight 
              position={[5, 10, 5]} 
              intensity={0.7} 
              color="#ffffff"
              castShadow
            />
            
            {/* 중앙 상단 보조 조명 - 전체적인 밝기 보완 */}
            <directionalLight 
              position={[0, 12, 3]} 
              intensity={0.5} 
              color="#f0f0f0"
            />
            
            {/* 환경맵 - 반사 효과를 위한 환경 설정 */}
            <Environment 
              preset="apartment" 
              background={false}  // 배경은 보이지 않게, 반사만 사용
              environmentIntensity={0.3}  // 환경맵 반영 강도 (기본값 1.0)
            />
            
            {/* 기본 요소들 */}
            <Room spaceInfo={spaceInfo} viewMode={viewMode} materialConfig={materialConfig} />
            
            {/* Configurator에서 표시되는 요소들 */}
            <ColumnGuides />
            <FurniturePlacementPlane spaceInfo={spaceInfo} />
            <PlacedFurniture />

            <SlotDropZones spaceInfo={spaceInfo} />
          </React.Suspense>
        </ThreeCanvas>
        
        {/* 단축키 안내 */}
        <KeyboardShortcuts />
      </div>
    </Space3DViewProvider>
  );
};

export default React.memo(Space3DView); 