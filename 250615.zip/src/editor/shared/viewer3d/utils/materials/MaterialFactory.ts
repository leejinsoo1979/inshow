import * as THREE from 'three';
import { TextureGenerator } from './TextureGenerator';

/**
 * 재질 팩토리 클래스 - 기존 materials.ts의 모든 함수를 대체
 */
export class MaterialFactory {
  // 캐시를 위한 정적 맵
  private static materialCache = new Map<string, THREE.Material>();

  // 전역 에지 라인 재질 캐시
  private static globalEdgeLineMaterial: THREE.LineBasicMaterial | null = null;

  /**
   * 캐시된 재질 반환 (성능 최적화)
   */
  private static getCachedMaterial(key: string, factory: () => THREE.Material): THREE.Material {
    if (!this.materialCache.has(key)) {
      this.materialCache.set(key, factory());
    }
    return this.materialCache.get(key)!;
  }

  /**
   * 텍스처 최적화 설정 적용
   */
  private static optimizeTexture(texture: THREE.CanvasTexture): void {
    texture.wrapS = THREE.ClampToEdgeWrapping;
    texture.wrapT = THREE.ClampToEdgeWrapping;
    texture.magFilter = THREE.LinearFilter;
    texture.minFilter = THREE.LinearMipmapLinearFilter;
    texture.generateMipmaps = true;
  }

  /**
   * 기본 재질 생성 헬퍼
   */
  private static createBasicMaterial(
    texture: THREE.CanvasTexture,
    options: {
      transparent?: boolean;
      opacity?: number;
      side?: THREE.Side;
      fog?: boolean;
      alphaTest?: number;
      emissive?: THREE.Color;
    } = {}
  ): THREE.MeshLambertMaterial {
    this.optimizeTexture(texture);

    return new THREE.MeshLambertMaterial({
      map: texture,
      transparent: options.transparent || false,
      opacity: options.opacity || 1.0,
      side: options.side || THREE.FrontSide,
      fog: options.fog !== undefined ? options.fog : false,
      ...(options.alphaTest && { alphaTest: options.alphaTest }),
      ...(options.emissive && { emissive: options.emissive })
    });
  }

  /**
   * 벽면용 재질 (커스텀 색상 지원)
   */
  static createWallMaterial(baseColor: string = '#e0e0e0'): THREE.MeshLambertMaterial {
    return this.getCachedMaterial(`wall_${baseColor}`, () => {
      const texture = TextureGenerator.createWallGradientTexture();
      return this.createBasicMaterial(texture);
    }) as THREE.MeshLambertMaterial;
  }

  /**
   * 외부 벽면용 재질
   */
  static createOuterWallMaterial(): THREE.MeshLambertMaterial {
    return this.getCachedMaterial('outerWall', () => {
      const texture = TextureGenerator.createOuterWallGradientTexture();
      return this.createBasicMaterial(texture);
    }) as THREE.MeshLambertMaterial;
  }

  /**
   * 바닥용 재질
   */
  static createFloorMaterial(): THREE.MeshLambertMaterial {
    return this.getCachedMaterial('floor', () => {
      const texture = TextureGenerator.createFloorGradientTexture();
      return this.createBasicMaterial(texture);
    }) as THREE.MeshLambertMaterial;
  }

  /**
   * 깊이 기반 외부 벽면용 재질
   */
  static createDepthBasedWallMaterial(): THREE.MeshLambertMaterial {
    return this.getCachedMaterial('depthWall', () => {
      const texture = TextureGenerator.createDepthBasedWallGradientTexture();
      return this.createBasicMaterial(texture, {
        transparent: true,
        opacity: 0.95,
        side: THREE.DoubleSide,
        fog: false
      });
    }) as THREE.MeshLambertMaterial;
  }

  /**
   * 깊이 기반 투명도 재질
   */
  static createDepthTransparencyMaterial(): THREE.MeshLambertMaterial {
    return this.getCachedMaterial('depthTransparency', () => {
      const texture = TextureGenerator.createDepthTransparencyTexture();
      return this.createBasicMaterial(texture, {
        transparent: true,
        opacity: 1.0,
        side: THREE.DoubleSide,
        fog: false,
        alphaTest: 0.01,
        emissive: new THREE.Color(0.2, 0.2, 0.2)
      });
    }) as THREE.MeshLambertMaterial;
  }

  /**
   * 방향별 투명도 재질 생성 (좌측, 상단, 우측)
   */
  static createDirectionalTransparencyMaterial(direction: 'left' | 'top' | 'right'): THREE.MeshLambertMaterial {
    return this.getCachedMaterial(`transparency-${direction}`, () => {
      // 방향에 따라 다른 텍스처 사용
      let texture;
      switch (direction) {
        case 'left':
          texture = TextureGenerator.createLeftWallDepthTransparencyTexture();
          break;
        case 'top':
          texture = TextureGenerator.createTopWallDepthTransparencyTexture();
          break;
        case 'right':
          texture = TextureGenerator.createRightWallDepthTransparencyTexture();
          break;
        default:
          texture = TextureGenerator.createDepthTransparencyTexture();
      }
      
      return this.createBasicMaterial(texture, {
        transparent: true,
        opacity: 1.0,
        side: THREE.DoubleSide,
        fog: false,
        alphaTest: 0.01,
        emissive: new THREE.Color(0.1, 0.1, 0.1)
      });
    }) as THREE.MeshLambertMaterial;
  }

  /**
   * 단색 재질 (2D 모드용)
   */
  static createFlatMaterial(color: string = '#ffffff'): THREE.MeshBasicMaterial {
    return this.getCachedMaterial(`flat-${color}`, () => {
      return new THREE.MeshBasicMaterial({
        color: new THREE.Color(color),
        transparent: false,
        fog: false
      });
    }) as THREE.MeshBasicMaterial;
  }

  /**
   * 엣지 라인 재질
   */
  static createEdgeLineMaterial(color: string = '#000000'): THREE.LineBasicMaterial {
    return this.getCachedMaterial(`edge-${color}`, () => {
      return new THREE.LineBasicMaterial({
        color: new THREE.Color(color),
        linewidth: 1
      });
    }) as THREE.LineBasicMaterial;
  }

  /**
   * 단색 프레임용 재질 (도어 색상과 완전히 동일)
   */
  static createSolidFrameMaterial(color: string = '#d0d0d0'): THREE.MeshPhysicalMaterial {
    // 캐싱 제거 - 매번 새로운 재질 인스턴스 생성하여 색상 동기화 문제 방지
    return new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(color),
      transparent: false,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
      metalness: 0.3,
      roughness: 0.1,
      reflectivity: 0.9,
      envMapIntensity: 1.5,
      emissive: new THREE.Color(color).multiplyScalar(0.1)
    });
  }



  /**
   * 캐시 정리 (메모리 관리)
   */
  static clearCache(): void {
    this.materialCache.forEach(material => {
      material.dispose();
    });
    this.materialCache.clear();
  }

  /**
   * 전역 에지 라인 재질 가져오기 (싱글톤 패턴)
   */
  static getGlobalEdgeLineMaterial(): THREE.LineBasicMaterial {
    if (!this.globalEdgeLineMaterial) {
      this.globalEdgeLineMaterial = this.createEdgeLineMaterial('#000000');
    }
    return this.globalEdgeLineMaterial;
  }
} 