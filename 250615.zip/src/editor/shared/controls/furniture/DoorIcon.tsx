import React from 'react';

interface DoorIconProps {
  isActive: boolean;
  onClick: (e: React.MouseEvent) => void;
  disabled?: boolean;
  className?: string;
}

const DoorIcon: React.FC<DoorIconProps> = ({ isActive, onClick, disabled = false, className = '' }) => {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`door-icon-button ${className}`}
      style={{
        width: '24px',
        height: '28px',
        border: 'none',
        borderRadius: '4px',
        backgroundColor: disabled ? '#9ca3af' : (isActive ? '#10b981' : '#9ca3af'),
        cursor: disabled ? 'not-allowed' : 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'all 0.2s ease',
        padding: '0',
      }}
      title={disabled ? '비활성화됨' : (isActive ? '도어 있음' : '도어 없음')}
    >
      <svg
        width="14"
        height="14"
        viewBox="0 0 14 14"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* 도어 프레임 */}
        <rect
          x="1"
          y="1"
          width="12"
          height="12"
          rx="1"
          stroke="white"
          strokeWidth="1"
          fill="none"
        />
        
        {/* 도어 패널 (활성화 시에만 표시) */}
        {isActive && (
          <>
            <rect
              x="2"
              y="2"
              width="10"
              height="10"
              rx="0.5"
              fill="white"
              fillOpacity="0.3"
            />
            
            {/* 도어 손잡이 */}
            <circle
              cx="10"
              cy="7"
              r="0.9"
              fill="white"
            />
          </>
        )}
        
        {/* 비활성화 시 X 표시 */}
        {!isActive && !disabled && (
          <>
            <line
              x1="4"
              y1="4"
              x2="10"
              y2="10"
              stroke="white"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <line
              x1="10"
              y1="4"
              x2="4"
              y2="10"
              stroke="white"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </>
        )}
      </svg>
    </button>
  );
};

export default DoorIcon; 