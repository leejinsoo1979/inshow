import React, { useState, useEffect, useRef } from 'react';
import { SpaceInfo, SurroundType, FrameSize } from '@/store/editorStore';
import styles from '../styles/common.module.css';
import { useDerivedSpaceStore } from '@/store/derivedSpaceStore';
import { useSurroundCalculations } from './hooks/useSurroundCalculations';
import SurroundTypeSelector from './components/SurroundTypeSelector';
import GapControls from './components/GapControls';
import FrameSizeControls from './components/FrameSizeControls';

interface SurroundControlsProps {
  spaceInfo: SpaceInfo;
  onUpdate: (updates: Partial<SpaceInfo>) => void;
}

const SurroundControls: React.FC<SurroundControlsProps> = ({ spaceInfo, onUpdate }) => {
  // 파생 상태 스토어 사용
  const derivedStore = useDerivedSpaceStore();
  
  // 이전 spaceInfo 값을 추적하여 불필요한 재계산 방지
  const prevSpaceInfoRef = useRef(spaceInfo);
  
  // 기존 로컬 상태들
  const isSurround = spaceInfo.surroundType === 'surround';
  const isNoSurround = spaceInfo.surroundType === 'no-surround';
  const hasLeftWall = spaceInfo.wallConfig.left;
  const hasRightWall = spaceInfo.wallConfig.right;
  const END_PANEL_WIDTH = 20; // 고정 20mm

  const [frameSize, setFrameSize] = useState<FrameSize>(() => {
    if (!spaceInfo.frameSize) return { left: 50, right: 50, top: 50 };
    return {
      left: !hasLeftWall && isSurround ? END_PANEL_WIDTH : spaceInfo.frameSize.left,
      right: !hasRightWall && isSurround ? END_PANEL_WIDTH : spaceInfo.frameSize.right,
      top: spaceInfo.frameSize.top,
    };
  });

  const [gapSize, setGapSize] = useState<2 | 3>(spaceInfo.gapConfig?.size || 2);

  // 계산 로직을 커스텀 훅으로 분리
  const { noSurroundFrameWidth, surroundFrameWidth, columnInfo } = useSurroundCalculations(
    spaceInfo,
    hasLeftWall,
    hasRightWall
  );

  // 파생 상태 스토어 동기화 - spaceInfo 변경 시 재계산
  useEffect(() => {
    const prev = prevSpaceInfoRef.current;
    const current = spaceInfo;
    
    // 실제로 중요한 값들이 변경되었을 때만 재계산
    if (
      prev.width !== current.width ||
      prev.surroundType !== current.surroundType ||
      JSON.stringify(prev.frameSize) !== JSON.stringify(current.frameSize) ||
      JSON.stringify(prev.gapConfig) !== JSON.stringify(current.gapConfig) ||
      prev.customColumnCount !== current.customColumnCount
    ) {
      derivedStore.recalculateFromSpaceInfo(spaceInfo);
      prevSpaceInfoRef.current = spaceInfo;
    }
  }, [spaceInfo.width, spaceInfo.surroundType, spaceInfo.frameSize, spaceInfo.gapConfig, spaceInfo.customColumnCount, derivedStore]);

  // 벽이 없는 쪽은 항상 20mm 엔드 패널로 유지
  useEffect(() => {
    if (isSurround && spaceInfo.frameSize) {
      let needsUpdate = false;
      const updates = { ...spaceInfo.frameSize };
      
      if (!hasLeftWall && updates.left !== END_PANEL_WIDTH) {
        updates.left = END_PANEL_WIDTH;
        needsUpdate = true;
      }
      
      if (!hasRightWall && updates.right !== END_PANEL_WIDTH) {
        updates.right = END_PANEL_WIDTH;
        needsUpdate = true;
      }
      
      if (needsUpdate) {
        setTimeout(() => {
          onUpdate({ frameSize: updates });
        }, 0);
      }
    }
  }, [isSurround, hasLeftWall, hasRightWall, spaceInfo.frameSize]);

  // 서라운드 타입 변경 처리
  const handleSurroundTypeChange = (type: SurroundType) => {
    const updates: Partial<SpaceInfo> = {
      surroundType: type,
    };

    if (type === 'surround') {
      updates.frameSize = {
        left: hasLeftWall ? 50 : END_PANEL_WIDTH,
        right: hasRightWall ? 50 : END_PANEL_WIDTH,
        top: 50,
      };
      updates.gapConfig = undefined;
    } else {
      // 노서라운드(타이트) 설정
      const gapSizeValue = 2; // 기본 이격거리
      
      updates.frameSize = {
        left: 0, // 좌측 프레임 제거
        right: 0, // 우측 프레임 제거
        top: 50, // 상단 프레임은 유지
      };
      
      updates.gapConfig = {
        size: gapSizeValue,
      };
    }

    onUpdate(updates);
  };

  // 프레임 크기 변경 핸들러
  const handleFrameSizeChange = (dimension: 'left' | 'right' | 'top', value: string) => {
    // 벽이 없는 쪽은 수정 불가능
    if ((dimension === 'left' && !hasLeftWall) || (dimension === 'right' && !hasRightWall)) {
      return;
    }
    
    // 숫자만 입력 가능하도록
    if (value === '' || /^\d+$/.test(value)) {
      const newFrameSize = { ...frameSize, [dimension]: value === '' ? '' : parseInt(value) };
      setFrameSize(newFrameSize);
    }
  };

  // 프레임 크기 업데이트 (blur 또는 Enter 시)
  const handleFrameSizeBlur = (dimension: 'left' | 'right' | 'top') => {
    if (!spaceInfo.frameSize) return;
    
    // 벽이 없는 쪽은 수정 불가능
    if ((dimension === 'left' && !hasLeftWall) || (dimension === 'right' && !hasRightWall)) {
      return;
    }
    
    let value = frameSize[dimension];
    
    // 문자열이면 숫자로 변환
    if (typeof value === 'string') {
      value = value === '' ? 50 : parseInt(value);
    }

    // 좌우 프레임은 40~100mm 범위, 상단 프레임은 10~200mm 범위
    if (dimension === 'left' || dimension === 'right') {
      if (value < 40) value = 40;
      if (value > 100) value = 100;
    } else {
      if (value < 10) value = 10;
      if (value > 200) value = 200;
    }

    // 로컬 상태 업데이트
    setFrameSize(prev => ({ ...prev, [dimension]: value }));

    // 값에 변화가 있을 때만 업데이트
    const currentValue = spaceInfo.frameSize[dimension as keyof typeof spaceInfo.frameSize];
    if (value !== currentValue) {
      onUpdate({
        frameSize: {
          ...spaceInfo.frameSize,
          [dimension]: value,
        },
      });
    }
  };

  // Enter 키 처리
  const handleKeyDown = (e: React.KeyboardEvent, dimension: 'left' | 'right' | 'top') => {
    if (e.key === 'Enter') {
      handleFrameSizeBlur(dimension);
    }
  };

  // 이격 크기 변경 핸들러
  const handleGapSizeChange = (size: 2 | 3) => {
    setGapSize(size);
    onUpdate({
      gapConfig: {
        size,
      },
    });
  };

  return (
    <div className={styles.container}>
      {/* 서라운드 타입 선택 */}
      <SurroundTypeSelector
        surroundType={spaceInfo.surroundType || 'surround'}
        onSurroundTypeChange={handleSurroundTypeChange}
      />

      {/* 노서라운드 선택 시 이격거리 설정 */}
      {isNoSurround && (
        <GapControls
          gapSize={gapSize}
          onGapSizeChange={handleGapSizeChange}
        />
      )}

      {/* 프레임 크기 설정 */}
      <FrameSizeControls
        frameSize={frameSize}
        hasLeftWall={hasLeftWall}
        hasRightWall={hasRightWall}
        isSurround={isSurround}
        surroundFrameWidth={surroundFrameWidth}
        noSurroundFrameWidth={noSurroundFrameWidth}
        gapSize={gapSize}
        spaceWidth={spaceInfo.width}
        columnInfo={columnInfo}
        onFrameSizeChange={handleFrameSizeChange}
        onFrameSizeBlur={handleFrameSizeBlur}
        onKeyDown={handleKeyDown}
      />
    </div>
  );
};

export default SurroundControls; 