import React, { useState, useEffect, useRef } from 'react';
import { SpaceInfo } from '@/store/editorStore';
import styles from '../styles/common.module.css';
import { 
  validateColumnCount,
  getDefaultColumnCount 
} from '@/editor/shared/utils/indexing';
import { useDerivedSpaceStore } from '@/store/derivedSpaceStore';
import { useBaseCalculations } from './hooks/useBaseCalculations';
import BaseTypeSelector from './components/BaseTypeSelector';
import PlacementControls from './components/PlacementControls';
import ColumnCountControls from './components/ColumnCountControls';

interface BaseControlsProps {
  spaceInfo: SpaceInfo;
  onUpdate: (updates: Partial<SpaceInfo>) => void;
}

const BaseControls: React.FC<BaseControlsProps> = ({ spaceInfo, onUpdate }) => {
  const derivedStore = useDerivedSpaceStore();
  
  // 이전 spaceInfo 값을 추적하여 불필요한 재계산 방지
  const prevSpaceInfoRef = useRef(spaceInfo);
  
  // 로컬 상태들
  const [baseHeight, setBaseHeight] = useState<string | number>(() => 
    spaceInfo.baseConfig?.height?.toString() || '65'
  );
  const [floatHeight, setFloatHeight] = useState<string | number>(() => 
    spaceInfo.baseConfig?.floatHeight?.toString() || '60'
  );

  // 컬럼 수 관련 상태
  const [columnCount, setColumnCount] = useState<number>(() => {
    if (derivedStore.isCalculated) {
      return derivedStore.columnCount;
    }
    // 파생 스토어가 아직 계산되지 않았으면 기본값 사용
    return spaceInfo.customColumnCount || 4; // 임시 기본값
  });

  // 계산 로직을 커스텀 훅으로 분리
  const { internalWidth, columnLimits, currentColumnWidth, isAutoMode, derivedColumnCount } = useBaseCalculations(
    spaceInfo,
    columnCount
  );

  // 파생 상태 스토어와 동기화
  useEffect(() => {
    const prev = prevSpaceInfoRef.current;
    const current = spaceInfo;
    
    // 실제로 중요한 값들이 변경되었을 때만 재계산
    const shouldRecalculate = (
      !derivedStore.isCalculated || // 아직 계산되지 않았다면 무조건 계산
      prev.width !== current.width ||
      prev.surroundType !== current.surroundType ||
      JSON.stringify(prev.frameSize) !== JSON.stringify(current.frameSize) ||
      JSON.stringify(prev.gapConfig) !== JSON.stringify(current.gapConfig) ||
      prev.customColumnCount !== current.customColumnCount
    );
    
    if (shouldRecalculate) {
      derivedStore.recalculateFromSpaceInfo(spaceInfo);
      prevSpaceInfoRef.current = spaceInfo;
    }
  }, [spaceInfo, derivedStore]);

  // baseConfig 변경 시 로컬 상태 동기화
  useEffect(() => {
    if (spaceInfo.baseConfig) {
      setBaseHeight(spaceInfo.baseConfig.height);
      setFloatHeight(spaceInfo.baseConfig.floatHeight || 60);
    }
  }, [spaceInfo.baseConfig]);

  // 파생 스토어의 컬럼 수가 변경되면 로컬 상태 업데이트
  useEffect(() => {
    if (derivedStore.isCalculated) {
      // 사용자 지정 컬럼 수가 있으면 검증 후 사용
      if (spaceInfo.customColumnCount) {
        const validation = validateColumnCount(spaceInfo.customColumnCount, internalWidth);
        
        if (validation.isValid) {
          setColumnCount(spaceInfo.customColumnCount);
        } else {
          // 유효하지 않으면 최소값으로 조정하고 자동 저장
          const adjustedCount = columnLimits.minColumns;
          setColumnCount(adjustedCount);
          if (spaceInfo.customColumnCount !== adjustedCount) {
            setTimeout(() => {
              onUpdate({ customColumnCount: adjustedCount });
            }, 0);
          }
        }
      } else {
        // 자동 모드: 파생 스토어의 계산된 값 사용
        setColumnCount(derivedColumnCount);
      }
    }
  }, [derivedStore.isCalculated, derivedColumnCount, spaceInfo.customColumnCount, internalWidth, columnLimits.minColumns, onUpdate]);

  // 받침대 타입 변경 처리
  const handleBaseTypeChange = (type: 'floor' | 'stand') => {
    // 기존 baseConfig가 없으면 기본값으로 초기화하여 생성
    const currentBaseConfig = spaceInfo.baseConfig || { type: 'floor', height: 65 };
    
    onUpdate({
      baseConfig: {
        ...currentBaseConfig,
        type,
        // 받침대 있음 선택 시 placementType 속성 제거
        ...(type === 'floor' ? {} : { placementType: currentBaseConfig.placementType || 'ground' }),
      },
    });
  };

  // 배치 유형 변경 처리
  const handlePlacementTypeChange = (placementType: 'ground' | 'float') => {
    // 기존 baseConfig가 없으면 기본값으로 초기화하여 생성
    const currentBaseConfig = spaceInfo.baseConfig || { type: 'stand', height: 65 };
    
    onUpdate({
      baseConfig: {
        ...currentBaseConfig,
        placementType,
        // 띄워서 배치 선택 시 기본 높이 설정
        ...(placementType === 'float' ? { floatHeight: currentBaseConfig.floatHeight || 60 } : {}),
      },
    });
  };

  // 높이 입력 처리
  const handleHeightChange = (value: string) => {
    // 숫자와 빈 문자열만 허용
    if (value === '' || /^\d+$/.test(value)) {
      setBaseHeight(value);
    }
  };

  // 띄움 높이 입력 처리
  const handleFloatHeightChange = (value: string) => {
    // 숫자와 빈 문자열만 허용
    if (value === '' || /^\d+$/.test(value)) {
      setFloatHeight(value);
    }
  };

  // 높이 업데이트 (blur 또는 Enter 시)
  const handleHeightBlur = () => {
    // 기존 baseConfig가 없으면 기본값으로 초기화하여 생성
    const currentBaseConfig = spaceInfo.baseConfig || { type: 'floor', height: 65 };
    
    let value = baseHeight;
    
    // 문자열이면 숫자로 변환
    if (typeof value === 'string') {
      value = value === '' ? 65 : parseInt(value);
    }

    // 최소값 (50mm) 보장
    if (value < 50) {
      value = 50;
    }

    // 최대값 (100mm) 보장
    if (value > 100) {
      value = 100;
    }

    // 로컬 상태 업데이트
    setBaseHeight(value);

    // 값이 변경된 경우만 업데이트
    if (value !== currentBaseConfig.height) {
      onUpdate({
        baseConfig: {
          ...currentBaseConfig,
          height: value,
        },
      });
    }
  };

  // 띄움 높이 업데이트 (blur 또는 Enter 시)
  const handleFloatHeightBlur = () => {
    // 기존 baseConfig가 없으면 기본값으로 초기화하여 생성
    const currentBaseConfig = spaceInfo.baseConfig || { type: 'stand', height: 0, floatHeight: 60 };
    
    let value = floatHeight;
    
    // 문자열이면 숫자로 변환
    if (typeof value === 'string') {
      value = value === '' ? 60 : parseInt(value);
    }

    // 최소값 (0mm) 보장
    if (value < 0) {
      value = 0;
    }

    // 최대값 (200mm) 보장
    if (value > 200) {
      value = 200;
    }

    // 로컬 상태 업데이트
    setFloatHeight(value);

    // 값이 변경된 경우만 업데이트
    if (value !== currentBaseConfig.floatHeight) {
      onUpdate({
        baseConfig: {
          ...currentBaseConfig,
          floatHeight: value,
        },
      });
    }
  };

  // Enter 키 처리
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleHeightBlur();
    }
  };

  // 띄움 높이 Enter 키 처리
  const handleFloatKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleFloatHeightBlur();
    }
  };

  // 컬럼 수 조정 핸들러
  const handleColumnCountChange = (newCount: number) => {
    const validation = validateColumnCount(newCount, internalWidth);
    
    if (validation.isValid) {
      setColumnCount(newCount);
      onUpdate({
        customColumnCount: newCount
      });
    }
  };

  // 컬럼 수 자동 모드로 리셋
  const handleResetColumnCount = () => {
    const defaultCount = getDefaultColumnCount(internalWidth);
    setColumnCount(defaultCount);
    onUpdate({
      customColumnCount: undefined
    });
  };

  return (
    <div className={styles.container}>
      {/* 받침대 타입 선택 */}
      <BaseTypeSelector
        baseConfig={spaceInfo.baseConfig}
        onBaseTypeChange={handleBaseTypeChange}
      />

      {/* 배치 설정 및 높이 조절 */}
      <PlacementControls
        baseConfig={spaceInfo.baseConfig}
        baseHeight={baseHeight}
        floatHeight={floatHeight}
        onPlacementTypeChange={handlePlacementTypeChange}
        onHeightChange={handleHeightChange}
        onFloatHeightChange={handleFloatHeightChange}
        onHeightBlur={handleHeightBlur}
        onFloatHeightBlur={handleFloatHeightBlur}
        onKeyDown={handleKeyDown}
        onFloatKeyDown={handleFloatKeyDown}
      />

      {/* 컬럼 수 설정 */}
      <ColumnCountControls
        columnCount={columnCount}
        internalWidth={internalWidth}
        columnLimits={columnLimits}
        currentColumnWidth={currentColumnWidth}
        isAutoMode={isAutoMode}
        onColumnCountChange={handleColumnCountChange}
        onResetColumnCount={handleResetColumnCount}
      />
    </div>
  );
};

export default BaseControls; 