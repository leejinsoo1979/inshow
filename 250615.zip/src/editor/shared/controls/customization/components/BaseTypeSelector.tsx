import React from 'react';
import { BaseConfig } from '@/store/editorStore';
import styles from '../../styles/common.module.css';

interface BaseTypeSelectorProps {
  baseConfig?: BaseConfig;
  onBaseTypeChange: (type: 'floor' | 'stand') => void;
}

const BaseTypeSelector: React.FC<BaseTypeSelectorProps> = ({
  baseConfig,
  onBaseTypeChange
}) => {
  const isFloor = baseConfig?.type === 'floor' || !baseConfig;
  const isStand = baseConfig?.type === 'stand';

  return (
    <div className={styles.section}>
      <span className={styles.label}>받침대 설정</span>
      <div className={styles.radioGroup}>
        <button
          className={`${styles.button} ${isFloor ? styles.buttonActive : ''}`}
          onClick={() => onBaseTypeChange('floor')}
        >
          받침대 있음
        </button>
        <button
          className={`${styles.button} ${isStand ? styles.buttonActive : ''}`}
          onClick={() => onBaseTypeChange('stand')}
        >
          받침대 없음
        </button>
      </div>
    </div>
  );
};

export default BaseTypeSelector; 