import React from 'react';
import { SurroundType } from '@/store/editorStore';
import styles from '../../styles/common.module.css';

interface SurroundTypeSelectorProps {
  surroundType: SurroundType;
  onSurroundTypeChange: (type: SurroundType) => void;
}

const SurroundTypeSelector: React.FC<SurroundTypeSelectorProps> = ({
  surroundType,
  onSurroundTypeChange
}) => {
  const isSurround = surroundType === 'surround';
  const isNoSurround = surroundType === 'no-surround';

  return (
    <div className={styles.section}>
      <span className={styles.label}>맞춤 옵션</span>
      <div className={styles.radioGroup}>
        <button
          className={`${styles.button} ${isNoSurround ? styles.buttonActive : ''}`}
          onClick={() => onSurroundTypeChange('no-surround')}
        >
          노서라운드 (타이트)
        </button>
        <button
          className={`${styles.button} ${isSurround ? styles.buttonActive : ''}`}
          onClick={() => onSurroundTypeChange('surround')}
        >
          서라운드 (일반)
        </button>
      </div>
    </div>
  );
};

export default SurroundTypeSelector; 