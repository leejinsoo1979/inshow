import React, { useState, useEffect } from 'react';
import { SpaceInfo } from '@/store/editorStore';
import styles from '../styles/common.module.css';

interface DepthControlProps {
  spaceInfo: SpaceInfo;
  onUpdate: (updates: Partial<SpaceInfo>) => void;
}

const DepthControl: React.FC<DepthControlProps> = ({ spaceInfo, onUpdate }) => {
  const [error, setError] = useState<string>();
  
  // 안전한 기본값 제공
  const safeDepth = spaceInfo?.depth || 580;
  
  // 입력 중인 값을 위한 로컬 상태
  const [inputValue, setInputValue] = useState<string>(safeDepth.toString());

  // spaceInfo가 변경되면 로컬 상태 업데이트
  useEffect(() => {
    setInputValue(safeDepth.toString());
  }, [safeDepth]);

  // 입력 중에는 로컬 상태만 업데이트
  const handleInputChange = (value: string) => {
    // 숫자와 빈 문자열만 허용
    if (value === '' || /^\d+$/.test(value)) {
      setInputValue(value);
    }
  };

  // 입력 완료 후 유효성 검사 및 상태 업데이트
  const handleInputBlur = () => {
    const value = inputValue;
    if (value === '') {
      // 빈 값인 경우 기존 값으로 되돌림
      setInputValue(safeDepth.toString());
      return;
    }
    
    const numValue = parseInt(value);
    
    // 범위 검증 (깊이: 130~780mm)
    const minValue = 130;
    const maxValue = 780;
    
    // 에러 메시지 업데이트
    if (numValue < minValue) {
      setError(`최소 ${minValue}mm 이상이어야 합니다`);
    } else if (numValue > maxValue) {
      setError(`최대 ${maxValue}mm 이하여야 합니다`);
    } else {
      setError(undefined);
      // 유효한 값이면 상태 업데이트
      onUpdate({
        depth: numValue
      });
    }
  };

  // Enter 키 처리
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleInputBlur();
    }
  };

  return (
    <div className={styles.inputWrapper}>
      <label className={styles.inputLabel}>깊이 (130mm ~ 780mm)</label>
      <div className={styles.inputWithUnit}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => handleInputChange(e.target.value)}
          onBlur={handleInputBlur}
          onKeyDown={handleKeyDown}
          className={`${styles.input} ${styles.inputWithUnitField} ${error ? styles.inputError : ''}`}
          placeholder="130-780"
        />
        <span className={styles.unit}>mm</span>
      </div>
      {error && <div className={styles.errorMessage}>{error}</div>}
    </div>
  );
};

export default DepthControl; 