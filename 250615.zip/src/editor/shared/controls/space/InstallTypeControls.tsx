import React from 'react';
import { SpaceInfo } from '@/store/editorStore';
import { INSTALL_TYPES, InstallType } from '../types';
import styles from '../styles/common.module.css';

interface InstallTypeControlsProps {
  spaceInfo: SpaceInfo;
  onUpdate: (updates: Partial<SpaceInfo>) => void;
}

const InstallTypeControls: React.FC<InstallTypeControlsProps> = ({ spaceInfo, onUpdate }) => {
  const handleInstallTypeChange = (type: InstallType) => {
    // 설치 유형에 따른 벽 구성 설정
    let wallConfig = { ...spaceInfo.wallConfig };
    
    switch (type) {
      case 'built-in':
        wallConfig = { left: true, right: true };
        break;
      case 'semi-standing':
        wallConfig = { left: true, right: false };
        break;
      case 'free-standing':
        wallConfig = { left: false, right: false };
        break;
    }

    onUpdate({
      installType: type,
      wallConfig,
    });
  };

  const handleWallConfigChange = (side: 'left' | 'right') => {
    onUpdate({
      wallConfig: {
        left: side === 'left',
        right: side === 'right',
      },
    });
  };

  return (
    <div className={styles.container}>
      <div className={styles.section}>
        <span className={styles.label}>설치 유형</span>
        <div className={styles.radioGroup}>
          {INSTALL_TYPES.map((type) => (
            <button
              key={type.type}
              className={`${styles.button} ${spaceInfo.installType === type.type ? styles.buttonActive : ''}`}
              onClick={() => handleInstallTypeChange(type.type)}
            >
              {type.label}
            </button>
          ))}
        </div>
      </div>

      {/* 세미스탠딩일 때만 벽 위치 선택 UI 표시 */}
      {spaceInfo.installType === 'semi-standing' && (
        <div className={styles.section}>
          <span className={styles.label}>벽 위치</span>
          <div className={styles.radioGroup}>
            <button
              className={`${styles.button} ${spaceInfo.wallConfig.left ? styles.buttonActive : ''}`}
              onClick={() => handleWallConfigChange('left')}
            >
              좌측
            </button>
            <button
              className={`${styles.button} ${spaceInfo.wallConfig.right ? styles.buttonActive : ''}`}
              onClick={() => handleWallConfigChange('right')}
            >
              우측
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default InstallTypeControls; 