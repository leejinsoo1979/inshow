// 새로운 모듈화된 indexing 시스템을 사용
// 기존 API는 완전히 유지되며, 내부 구현만 개선되었습니다
export * from './indexing/index'; 