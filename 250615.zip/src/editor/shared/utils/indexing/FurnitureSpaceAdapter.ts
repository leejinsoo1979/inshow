import { SpaceInfo } from '@/store/editorStore';
import { ModuleData } from '@/data/modules';
import { calculateInternalSpace } from '../../viewer3d/utils/geometry';
import { ColumnIndexer } from './ColumnIndexer';
import { FurniturePositioner } from './FurniturePositioner';

/**
 * 배치된 가구 모듈 타입
 */
interface PlacedModule {
  id: string;
  moduleId: string;
  position: { x: number; y: number; z: number };
  rotation: number;
  hasDoor?: boolean;
  slotIndex?: number;
  isDualSlot?: boolean;
}

/**
 * 가구 필터링 및 조정 결과 타입
 */
interface FurnitureFilterResult {
  validFurniture: Array<PlacedModule & {
    slotIndex: number;
    isDualSlot: boolean;
    isValidInCurrentSpace: boolean;
  }>;
  removedFurniture: Array<string>;
}

/**
 * 공간 변경 시 가구 적응 관련 유틸리티 클래스
 * 공간 크기 변경 시 기존 가구들의 유효성 검사 및 위치 조정을 담당
 */
export class FurnitureSpaceAdapter {
  /**
   * 공간 변경 시 가구 목록을 필터링하고 위치를 조정하는 함수
   */
  static filterAndAdjustFurniture(
    placedModules: Array<PlacedModule>,
    oldSpaceInfo: SpaceInfo,
    newSpaceInfo: SpaceInfo,
    getModuleById: (moduleId: string, internalSpace: { width: number; height: number; depth: number }, spaceInfo: SpaceInfo) => ModuleData | null
  ): FurnitureFilterResult {
    const oldIndexing = ColumnIndexer.calculateSpaceIndexing(oldSpaceInfo);
    const newIndexing = ColumnIndexer.calculateSpaceIndexing(newSpaceInfo);
    
    console.log('🔄 Space change detected:');
    console.log('Old columns:', oldIndexing.columnCount, 'New columns:', newIndexing.columnCount);
    console.log('🔧 Old space:', oldSpaceInfo.width, 'mm, Old columnWidth:', oldIndexing.columnWidth, 'mm');
    console.log('🔧 New space:', newSpaceInfo.width, 'mm, New columnWidth:', newIndexing.columnWidth, 'mm');
    
    const validFurniture: Array<PlacedModule & {
      slotIndex: number;
      isDualSlot: boolean;
      isValidInCurrentSpace: boolean;
    }> = [];
    const removedFurniture: Array<string> = [];
    
    placedModules.forEach(module => {
      // 내경 공간 계산 (getModuleById를 위해 필요)
      const oldInternalSpace = calculateInternalSpace(oldSpaceInfo);
      const moduleData = getModuleById(module.moduleId, oldInternalSpace, oldSpaceInfo);
      
      if (!moduleData) {
        removedFurniture.push(module.id);
        return;
      }
      
      // 듀얼 가구 여부 판별
      const isDualFurniture = Math.abs(moduleData.dimensions.width - (oldIndexing.columnWidth * 2)) < 50;
      
      // 현재 슬롯 인덱스 계산 (기존 데이터에 없다면 위치로부터 계산)
      let slotIndex = module.slotIndex;
      if (slotIndex === undefined) {
        slotIndex = ColumnIndexer.findSlotIndexFromPosition(module.position, oldIndexing, isDualFurniture);
      }
      
      // 새 공간에서 유효성 검증
      const isValid = FurniturePositioner.validateFurniturePosition(slotIndex, isDualFurniture, newIndexing);
      
      // 컬럼 수가 변경된 경우 추가 검증
      const columnCountChanged = oldIndexing.columnCount !== newIndexing.columnCount;
      
      if (isValid && !columnCountChanged) {
        // 새 위치 계산
        const newPosition = FurniturePositioner.adjustFurniturePosition(slotIndex, isDualFurniture, newIndexing);
        
        if (newPosition) {
          // 새로운 공간에 맞는 moduleId 계산
          let newModuleId = module.moduleId;
          if (moduleData.isDynamic) {
            // 새로운 공간의 실제 컬럼 폭 사용
            const actualNewColumnWidth = newIndexing.columnWidth;
            if (isDualFurniture) {
              newModuleId = `box-dual-${actualNewColumnWidth * 2}`;
            } else {
              newModuleId = `box-open-${actualNewColumnWidth}`;
            }
          }
          
          validFurniture.push({
            ...module,
            moduleId: newModuleId, // 새로운 moduleId 사용
            position: {
              ...module.position,
              x: newPosition.x
            },
            slotIndex,
            isDualSlot: isDualFurniture,
            isValidInCurrentSpace: true
          });
          console.log(`✅ Preserved furniture ${module.id} at slot ${slotIndex} with new moduleId: ${newModuleId} (columnWidth: ${newIndexing.columnWidth})`);
        } else {
          removedFurniture.push(module.id);
          console.log(`❌ Failed to adjust position for furniture ${module.id}`);
        }
      } else {
        removedFurniture.push(module.id);
        if (columnCountChanged) {
          console.log(`❌ Removed furniture ${module.id} (moduleId: ${module.moduleId}) - column count changed from ${oldIndexing.columnCount} to ${newIndexing.columnCount}`);
        } else {
          console.log(`❌ Removed furniture ${module.id} (moduleId: ${module.moduleId}) - slot ${slotIndex} not available in new space (isDual: ${isDualFurniture}, newColumns: ${newIndexing.columnCount})`);
        }
      }
    });
    
    console.log(`📊 Space change result: ${validFurniture.length} preserved, ${removedFurniture.length} removed`);
    
    return {
      validFurniture,
      removedFurniture
    };
  }
} 