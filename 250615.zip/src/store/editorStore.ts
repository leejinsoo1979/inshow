import { create } from 'zustand';
import { InstallType, FloorFinishConfig } from '@/editor/shared/controls/types';

// 기본 정보 타입
export interface BasicInfo {
  title: string;
  location: string;
}

// 커스터마이징 정보 타입
export interface Customization {
  material: string | null;
  color: string | null;
  size: {
    width: number;
    height: number;
    depth: number;
  } | null;
}

// Configurator 관련 추가 타입들
export type SurroundType = 'surround' | 'no-surround';

export interface FrameSize {
  left: number;
  right: number;
  top: number;
}

export interface GapConfig {
  size: 2 | 3; // mm 단위
}

export interface BaseConfig {
  type: 'floor' | 'stand';
  height: number;
  placementType?: 'ground' | 'float'; // 받침대 없음일 때 배치 방식
  floatHeight?: number; // 띄워서 배치 시 띄우는 높이
}

// 재질 설정 타입 추가
export interface MaterialConfig {
  interiorColor: string;
  doorColor: string;
}

// 공간 정보 타입
export interface SpaceInfo {
  width: number;
  height: number;
  depth: number;
  installType: InstallType;
  wallConfig: {
    left: boolean;
    right: boolean;
  };
  hasFloorFinish: boolean;
  floorFinish?: FloorFinishConfig;
  
  // Configurator 관련 추가 속성
  surroundType?: SurroundType;
  frameSize?: FrameSize;
  gapConfig?: GapConfig;
  baseConfig?: BaseConfig;
  
  // 컬럼 수 사용자 지정 속성
  customColumnCount?: number;
  
  // 재질 설정 추가
  materialConfig?: MaterialConfig;
}

// 전체 에디터 상태 타입
interface EditorState {
  // 상태
  basicInfo: BasicInfo;
  customization: Customization;
  isDirty: boolean;  // 변경사항 있음을 표시
  spaceInfo: SpaceInfo;
  
  // 기본 정보 액션
  setBasicInfo: (info: Partial<BasicInfo>) => void;
  resetBasicInfo: () => void;
  
  // 커스터마이징 액션
  setMaterial: (material: string | null) => void;
  setColor: (color: string | null) => void;
  setSize: (size: { width: number; height: number; depth: number } | null) => void;
  resetCustomization: () => void;
  
  // 공간 정보 액션
  setSpaceInfo: (info: Partial<SpaceInfo>) => void;
  resetSpaceInfo: () => void;
  
  // 전체 상태 관리
  resetAll: () => void;
  markAsSaved: () => void;
  
  // 재질 설정 초기화 액션 추가
  resetMaterialConfig: () => void;
}

// 초기 상태
const initialState: Omit<EditorState, 'setBasicInfo' | 'resetBasicInfo' | 'setMaterial' | 'setColor' | 'setSize' | 'resetCustomization' | 'resetAll' | 'markAsSaved' | 'setSpaceInfo' | 'resetSpaceInfo' | 'resetMaterialConfig'> = {
  basicInfo: {
    title: '',
    location: '',
  },
  customization: {
    material: null,
    color: null,
    size: null,
  },
  isDirty: false,
  spaceInfo: {
    width: 3600,
    height: 2400,
    depth: 580,
    installType: 'built-in',
    wallConfig: {
      left: true,
      right: true,
    },
    hasFloorFinish: false,
    floorFinish: {
      height: 50
    },
    // Configurator 초기값 설정
    surroundType: 'surround',
    frameSize: {
      left: 50,
      right: 50,
      top: 50
    },
    baseConfig: {
      type: 'floor',
      height: 65,
      placementType: 'ground'
    },
    // 재질 설정 초기값
    materialConfig: {
      interiorColor: '#FFFFFF', // 기본 내부 색상 (흰색)
      doorColor: '#FFFFFF'      // 기본 도어 색상 (흰색 - 테스트용)
    }
  },
};

export const useEditorStore = create<EditorState>()((set) => ({
  ...initialState,
  setBasicInfo: (info) =>
    set((state) => ({
      basicInfo: { ...state.basicInfo, ...info },
      isDirty: true,
    })),
  resetBasicInfo: () =>
    set({
      basicInfo: initialState.basicInfo,
      isDirty: true,
    }),
  setMaterial: (material) =>
    set((state) => ({
      customization: { ...state.customization, material },
      isDirty: true,
    })),
  setColor: (color) =>
    set((state) => ({
      customization: { ...state.customization, color },
      isDirty: true,
    })),
  setSize: (size) =>
    set((state) => ({
      customization: { ...state.customization, size },
      isDirty: true,
    })),
  resetCustomization: () =>
    set({
      customization: initialState.customization,
      isDirty: true,
    }),
  setSpaceInfo: (info) => {
    set((state) => {
      const newState = {
        spaceInfo: { ...state.spaceInfo, ...info },
        isDirty: true,
      };
      return newState;
    });
  },
  resetSpaceInfo: () =>
    set({
      spaceInfo: initialState.spaceInfo,
      isDirty: true,
    }),
  resetAll: () => set({ ...initialState, isDirty: false }),
  markAsSaved: () => set({ isDirty: false }),
  resetMaterialConfig: () =>
    set((state) => ({
      spaceInfo: {
        ...state.spaceInfo,
        materialConfig: {
          ...state.spaceInfo.materialConfig!,
          doorColor: '#FFFFFF'  // 흰색으로 초기화 (테스트용)
        }
      },
      isDirty: true,
    })),
})); 