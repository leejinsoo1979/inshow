import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// UI 상태 타입
interface UIState {
  // 뷰어 모드 상태
  viewMode: '2D' | '3D';
  
  // 문 열림/닫힘 상태
  doorsOpen: boolean;
  
  // 속성 패널용 선택된 모듈
  selectedModuleForProperties: string | null;
  
  // 액션들
  setViewMode: (mode: '2D' | '3D') => void;
  toggleDoors: () => void;
  setSelectedModuleForProperties: (moduleId: string | null) => void;
  resetUI: () => void;
}

// 초기 상태
const initialUIState = {
  viewMode: '2D' as const,  // 기본값은 2D
  doorsOpen: false,
  selectedModuleForProperties: null,
};

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      ...initialUIState,
      
      setViewMode: (mode) =>
        set({ viewMode: mode }),
      
      toggleDoors: () =>
        set((state) => ({ doorsOpen: !state.doorsOpen })),
      
      setSelectedModuleForProperties: (moduleId) =>
        set({ selectedModuleForProperties: moduleId }),
      
      resetUI: () =>
        set(initialUIState),
    }),
    {
      name: 'ui-store', // localStorage 키
      partialize: (state) => ({
        viewMode: state.viewMode,
        // doorsOpen과 selectedModuleForProperties는 세션별로 초기화
      }),
    }
  )
); 