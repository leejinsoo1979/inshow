import { describe, it, expect, beforeEach } from 'vitest'
import { useEditorStore } from '../editorStore'

describe('EditorStore', () => {
  beforeEach(() => {
    // 각 테스트 전에 스토어 초기화
    useEditorStore.getState().resetAll()
  })

  describe('초기 상태', () => {
    it('기본값들이 올바르게 설정되어야 한다', () => {
      const state = useEditorStore.getState()
      
      expect(state.basicInfo.title).toBe('')
      expect(state.basicInfo.location).toBe('')
      expect(state.spaceInfo.width).toBe(3600)
      expect(state.spaceInfo.height).toBe(2400)
      expect(state.isDirty).toBe(false)
    })
  })

  describe('spaceInfo 업데이트', () => {
    it('width 변경이 올바르게 적용되어야 한다', () => {
      const store = useEditorStore
      const initialWidth = store.getState().spaceInfo.width
      
      store.getState().setSpaceInfo({ width: 2400 })
      
      expect(store.getState().spaceInfo.width).toBe(2400)
      expect(store.getState().spaceInfo.width).not.toBe(initialWidth)
      expect(store.getState().isDirty).toBe(true)
    })

    it('여러 속성을 동시에 변경할 수 있어야 한다', () => {
      const store = useEditorStore
      
      store.getState().setSpaceInfo({ 
        width: 2700,
        height: 2200,
        installType: 'built-in'
      })
      
      const state = store.getState().spaceInfo
      expect(state.width).toBe(2700)
      expect(state.height).toBe(2200)
      expect(state.installType).toBe('built-in')
    })

    it('부분 업데이트 시 다른 속성들은 유지되어야 한다', () => {
      const store = useEditorStore
      
      // 초기 설정
      store.getState().setSpaceInfo({ 
        width: 3000,
        height: 2400,
        installType: 'built-in'
      })
      
      // width만 변경
      store.getState().setSpaceInfo({ width: 2400 })
      
      const state = store.getState().spaceInfo
      expect(state.width).toBe(2400)
      expect(state.height).toBe(2400) // 유지됨
      expect(state.installType).toBe('built-in') // 유지됨
    })
  })

  describe('customization 상태', () => {
    it('재료 정보가 올바르게 업데이트되어야 한다', () => {
      const store = useEditorStore
      
      store.getState().setMaterial('wood')
      
      expect(store.getState().customization.material).toBe('wood')
      expect(store.getState().isDirty).toBe(true)
    })

    it('색상 정보가 올바르게 업데이트되어야 한다', () => {
      const store = useEditorStore
      
      store.getState().setColor('brown')
      
      expect(store.getState().customization.color).toBe('brown')
      expect(store.getState().isDirty).toBe(true)
    })

    it('크기 정보가 올바르게 업데이트되어야 한다', () => {
      const store = useEditorStore
      
      store.getState().setSize({ width: 600, height: 2000, depth: 400 })
      
      const size = store.getState().customization.size
      expect(size?.width).toBe(600)
      expect(size?.height).toBe(2000)
      expect(size?.depth).toBe(400)
    })
  })



  describe('상태 지속성', () => {
    it('isDirty 플래그가 변경 시 활성화되어야 한다', () => {
      const store = useEditorStore
      
      expect(store.getState().isDirty).toBe(false)
      
      store.getState().setSpaceInfo({ width: 2400 })
      
      expect(store.getState().isDirty).toBe(true)
    })

    it('markAsSaved가 isDirty를 false로 설정해야 한다', () => {
      const store = useEditorStore
      
      store.getState().setSpaceInfo({ width: 2400 })
      expect(store.getState().isDirty).toBe(true)
      
      store.getState().markAsSaved()
      expect(store.getState().isDirty).toBe(false)
    })
  })

  describe('리셋 기능', () => {
    it('resetAll이 모든 상태를 초기값으로 되돌려야 한다', () => {
      const store = useEditorStore
      
      // 상태 변경
      store.getState().setBasicInfo({ title: 'Test', location: 'Seoul' })
      store.getState().setSpaceInfo({ width: 2400 })
      store.getState().setMaterial('wood')
      
      // 리셋
      store.getState().resetAll()
      
      const state = store.getState()
      expect(state.basicInfo.title).toBe('')
      expect(state.basicInfo.location).toBe('')
      expect(state.spaceInfo.width).toBe(3600)
      expect(state.customization.material).toBeNull()
      expect(state.isDirty).toBe(false)
    })

    it('개별 리셋 함수들이 정상 작동해야 한다', () => {
      const store = useEditorStore
      
      // 상태 변경
      store.getState().setBasicInfo({ title: 'Test', location: 'Seoul' })
      store.getState().setMaterial('wood')
      store.getState().setSpaceInfo({ width: 2400 })
      
      // 개별 리셋
      store.getState().resetBasicInfo()
      expect(store.getState().basicInfo.title).toBe('')
      expect(store.getState().basicInfo.location).toBe('')
      
      store.getState().resetCustomization()
      expect(store.getState().customization.material).toBeNull()
      
      store.getState().resetSpaceInfo()
      expect(store.getState().spaceInfo.width).toBe(3600)
    })
  })


}) 